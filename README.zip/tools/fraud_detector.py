import json
from datetime import datetime, timedelta
from mcp.shared.exceptions import McpError
from mcp.types import ErrorData, INTERNAL_ERROR, INVALID_PARAMS
from models.validation_models import FraudDetectionResult
from models import ExtractedDataModel

def detect_fraud(claim_data_path: str, llm) -> FraudDetectionResult:
    """
    Detect potential fraud in a claim by analyzing historical data and provider information.
    
    Args:
        claim_data_path: Path to the JSON file containing claim data
        llm: Language model instance for inference
        
    Returns:
        FraudDetectionResult: Fraud detection results including score and explanation
    """
    try:
        # Load claim data
        with open(claim_data_path, 'r') as f:
            claim_data = json.load(f)
        
        # Load past claims data
        with open('past_claims.json', 'r') as f:
            past_claims = json.load(f)
        
        # Create model instance from claim data
        claim = ExtractedDataModel(**claim_data)
        
        # Initialize score and red flags
        score = 100
        red_flags = []
        similar_claims = []
        
        # Check claimant history
        if claim.insurance_id in past_claims["claimants"]:
            claimant_history = past_claims["claimants"][claim.insurance_id]
            
            # Check for identical procedures
            identical_claims = [
                c for c in claimant_history["claims"]
                if any(p["code"] == claim.procedures[0]["code"] for p in c["procedures"])
            ]
            
            if len(identical_claims) >= 2:
                score -= 20
                red_flags.append(f"Claimant has {len(identical_claims)} identical past claims")
                similar_claims.extend(identical_claims)
            
            # Check for similar diagnoses within 6 months
            six_months_ago = datetime.strptime(claim.date_of_injury_illness, "%Y-%m-%d") - timedelta(days=180)
            recent_claims = [
                c for c in claimant_history["claims"]
                if datetime.strptime(c["date_of_service"], "%Y-%m-%d") > six_months_ago
                and any(d in claim.diagnosis for d in c["diagnosis"])
            ]
            
            if recent_claims:
                score -= 10
                red_flags.append(f"Same injury reported {len(recent_claims)} times in last 6 months")
                similar_claims.extend(recent_claims)
        
        # Check provider status
        provider_info = past_claims["providers"].get(claim.hospital_clinic, {})
        if provider_info.get("status") == "Under Investigation":
            score -= 40
            red_flags.append(f"Provider {claim.hospital_clinic} is under investigation")
        
        if provider_info.get("fraud_alerts"):
            score -= 20
            red_flags.append(f"Provider has {len(provider_info['fraud_alerts'])} fraud alerts")
        
        # Check for delayed filing
        service_date = datetime.strptime(claim.date_of_injury_illness, "%Y-%m-%d")
        filing_date = datetime.strptime(claim.submission_date, "%Y-%m-%d")
        if (filing_date - service_date).days > 60:
            score -= 10
            red_flags.append(f"Claim filed {((filing_date - service_date).days)} days after service")
        
        # Use OpenAI to analyze claim similarity if we have similar claims
        if similar_claims:
            prompt = f"""Compare the following claims and identify any patterns or suspicious similarities:
            Current claim: {json.dumps(claim_data, indent=2)}
            Past claims: {json.dumps(similar_claims, indent=2)}
            Focus on diagnosis, procedures, and claimed amounts."""
            
            response = llm.invoke(prompt)
            if "similar" in response.lower() or "pattern" in response.lower():
                score -= 15
                red_flags.append("AI analysis detected suspicious patterns in claim history")
        
        # Determine risk level
        if score >= 80:
            risk_level = "Low"
        elif score >= 50:
            risk_level = "Medium"
        else:
            risk_level = "High"
        
        # Generate explanation
        explanation = f"Fraud detection analysis for claim {claim.claim_id}:\n"
        if red_flags:
            explanation += "Red flags identified:\n"
            for flag in red_flags:
                explanation += f"- {flag}\n"
        else:
            explanation += "No significant red flags identified.\n"
        
        explanation += f"\nProvider status: {provider_info.get('status', 'Unknown')}\n"
        explanation += f"Final fraud score: {score}/100 (Risk Level: {risk_level})"
        
        return FraudDetectionResult(
            score=score,
            risk_level=risk_level,
            explanation=explanation,
            red_flags=red_flags,
            provider_status=provider_info.get("status", "Unknown"),
            similar_claims=similar_claims
        )
        
    except FileNotFoundError as e:
        raise McpError(ErrorData(INVALID_PARAMS, f"File not found: {str(e)}")) from e
    except json.JSONDecodeError as e:
        raise McpError(ErrorData(INVALID_PARAMS, f"Invalid JSON data: {str(e)}")) from e
    except Exception as e:
        raise McpError(ErrorData(INTERNAL_ERROR, f"Error detecting fraud: {str(e)}")) from e 