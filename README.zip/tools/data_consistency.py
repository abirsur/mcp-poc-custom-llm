import json
from difflib import SequenceMatcher
from mcp.shared.exceptions import McpError
from mcp.types import ErrorData, INTERNAL_ERROR, INVALID_PARAMS
from models.validation_models import ConsistencyResult
from models import ExtractedDataModel

def string_similarity(a: str, b: str) -> float:
    """Calculate similarity ratio between two strings"""
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()

def verify_data_consistency(portal_data_path: str, extracted_data_path: str, llm) -> ConsistencyResult:
    """
    Verify consistency between portal submission data and extracted document data.
    
    Args:
        portal_data_path: Path to the JSON file containing portal submission data
        extracted_data_path: Path to the JSON file containing extracted document data
        llm: Language model instance for inference
        
    Returns:
        ConsistencyResult: Consistency verification results including score and explanation
    """
    try:
        # Load both datasets
        with open(portal_data_path, 'r') as f:
            portal_data = json.load(f)
        
        with open(extracted_data_path, 'r') as f:
            extracted_data = json.load(f)
        
        # Create model instances
        portal_claim = ExtractedDataModel(**portal_data)
        extracted_claim = ExtractedDataModel(**extracted_data)
        
        # Initialize score and tracking lists
        score = 100
        mismatches = []
        critical_mismatches = []
        
        # Check critical fields (exact match required)
        critical_fields = {
            "insurance_id": "Patient ID",
            "date_of_injury_illness": "Date of Injury",
            "admission_date": "Admission Date",
            "discharge_date": "Discharge Date"
        }
        
        for field, display_name in critical_fields.items():
            portal_value = getattr(portal_claim, field)
            extracted_value = getattr(extracted_claim, field)
            
            if portal_value != extracted_value:
                score -= 30
                critical_mismatches.append(
                    f"{display_name} mismatch: Portal='{portal_value}', Extracted='{extracted_value}'"
                )
        
        # Check fuzzy match fields
        fuzzy_fields = {
            "claimant_name": "Patient Name",
            "hospital_clinic": "Hospital Name",
            "treating_physician": "Physician Name"
        }
        
        for field, display_name in fuzzy_fields.items():
            portal_value = getattr(portal_claim, field)
            extracted_value = getattr(extracted_claim, field)
            
            similarity = string_similarity(portal_value, extracted_value)
            if similarity < 0.7:
                score -= 20
                mismatches.append({
                    "field": display_name,
                    "portal_value": portal_value,
                    "extracted_value": extracted_value,
                    "similarity": f"{similarity:.2%}"
                })
            elif similarity < 1.0:
                score -= 10
                mismatches.append({
                    "field": display_name,
                    "portal_value": portal_value,
                    "extracted_value": extracted_value,
                    "similarity": f"{similarity:.2%}"
                })
        
        # Check diagnosis lists
        portal_diagnoses = set(d.lower() for d in portal_claim.diagnosis)
        extracted_diagnoses = set(d.lower() for d in extracted_claim.diagnosis)
        
        if portal_diagnoses != extracted_diagnoses:
            # Use OpenAI to analyze diagnosis differences
            prompt = f"""Compare these two sets of diagnoses and determine if they refer to the same conditions:
            Portal diagnoses: {list(portal_diagnoses)}
            Extracted diagnoses: {list(extracted_diagnoses)}
            Are these referring to the same medical conditions? Consider medical terminology and common variations."""
            
            response = llm.invoke(prompt)
            
            if "same" in response.lower() or "equivalent" in response.lower():
                score -= 10
                mismatches.append({
                    "field": "Diagnosis",
                    "portal_value": list(portal_diagnoses),
                    "extracted_value": list(extracted_diagnoses),
                    "explanation": "Different terminology for same conditions"
                })
            else:
                score -= 30
                critical_mismatches.append(
                    f"Diagnosis mismatch: Portal={list(portal_diagnoses)}, Extracted={list(extracted_diagnoses)}"
                )
        
        # Generate explanation
        explanation = f"Data consistency check for claim {portal_claim.claim_id}:\n\n"
        
        if critical_mismatches:
            explanation += "Critical mismatches found:\n"
            for mismatch in critical_mismatches:
                explanation += f"- {mismatch}\n"
            explanation += "\n"
        
        if mismatches:
            explanation += "Minor mismatches found:\n"
            for mismatch in mismatches:
                explanation += f"- {mismatch['field']}: "
                explanation += f"Portal='{mismatch['portal_value']}', "
                explanation += f"Extracted='{mismatch['extracted_value']}'"
                if 'similarity' in mismatch:
                    explanation += f" (Similarity: {mismatch['similarity']})"
                explanation += "\n"
            explanation += "\n"
        
        if not critical_mismatches and not mismatches:
            explanation += "All data points are consistent between portal submission and extracted documents.\n\n"
        
        explanation += f"Final consistency score: {score}/100"
        
        return ConsistencyResult(
            score=score,
            is_consistent=score >= 80,
            explanation=explanation,
            mismatches=mismatches,
            critical_mismatches=critical_mismatches
        )
        
    except FileNotFoundError as e:
        raise McpError(ErrorData(INVALID_PARAMS, f"File not found: {str(e)}")) from e
    except json.JSONDecodeError as e:
        raise McpError(ErrorData(INVALID_PARAMS, f"Invalid JSON data: {str(e)}")) from e
    except Exception as e:
        raise McpError(ErrorData(INTERNAL_ERROR, f"Error verifying data consistency: {str(e)}")) from e 