from typing import Dict, List, Any, TypedDict
from langgraph.graph import Graph, StateGraph
from langgraph.prebuilt import ToolExecutor
from langchain_core.messages import HumanMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import AzureChatOpenAI
import json
from datetime import datetime

from src.models.validation import (
    ValidationResult,
    FraudDetectionResult,
    ConsistencyResult,
    ProcessingStep,
    ClaimProcessingResult
)

class ClaimState(TypedDict):
    """State for the claim processing workflow"""
    claim_reference: str
    url: str
    claim_data_path: str
    portal_data_path: str
    extracted_data_path: str
    extracted_content: str
    validation_result: ValidationResult
    fraud_result: FraudDetectionResult
    consistency_result: ConsistencyResult
    final_result: ClaimProcessingResult
    processing_timestamp: str

def create_claim_processing_graph(llm: AzureChatOpenAI, tools: Dict[str, Any]) -> Graph:
    """Create the claim processing workflow graph"""
    
    # Initialize the graph
    workflow = StateGraph(ClaimState)
    
    # Define the nodes
    def extract_content(state: ClaimState) -> ClaimState:
        """Extract content from the URL"""
        result = tools["extract_contents_tool"](state["url"])
        return {
            "extracted_content": result,
            "processing_timestamp": datetime.utcnow().isoformat()
        }
    
    def validate_claim(state: ClaimState) -> ClaimState:
        """Validate the claim amount"""
        result = tools["validate_claim_amount_tool"](state["claim_data_path"])
        return {
            "validation_result": ValidationResult(**result),
            "processing_timestamp": datetime.utcnow().isoformat()
        }
    
    def detect_fraud(state: ClaimState) -> ClaimState:
        """Detect potential fraud"""
        result = tools["detect_fraud_tool"](state["claim_data_path"])
        return {
            "fraud_result": FraudDetectionResult(**result),
            "processing_timestamp": datetime.utcnow().isoformat()
        }
    
    def verify_consistency(state: ClaimState) -> ClaimState:
        """Verify data consistency"""
        result = tools["verify_data_consistency_tool"](
            state["portal_data_path"],
            state["extracted_data_path"]
        )
        return {
            "consistency_result": ConsistencyResult(**result),
            "processing_timestamp": datetime.utcnow().isoformat()
        }
    
    def merge_results(state: ClaimState) -> ClaimState:
        """Merge all results into a final response"""
        # Create processing steps
        processing_steps = {
            "content_extraction": ProcessingStep(
                status="completed",
                timestamp=datetime.fromisoformat(state["processing_timestamp"]),
                results={"content": state["extracted_content"]}
            ),
            "claim_validation": ProcessingStep(
                status="completed",
                timestamp=datetime.fromisoformat(state["processing_timestamp"]),
                results=state["validation_result"].dict()
            ),
            "fraud_detection": ProcessingStep(
                status="completed",
                timestamp=datetime.fromisoformat(state["processing_timestamp"]),
                results=state["fraud_result"].dict()
            ),
            "data_consistency": ProcessingStep(
                status="completed",
                timestamp=datetime.fromisoformat(state["processing_timestamp"]),
                results=state["consistency_result"].dict()
            )
        }
        
        # Generate a summary using the LLM
        prompt = ChatPromptTemplate.from_messages([
            ("system", "You are an expert claims analyst. Summarize the following claim analysis results:"),
            MessagesPlaceholder(variable_name="results"),
            ("human", f"Please provide a concise summary of the claim analysis for claim reference {state['claim_reference']}, highlighting any critical issues or concerns.")
        ])
        
        chain = prompt | llm
        
        summary = chain.invoke({
            "results": json.dumps({
                "validation": state["validation_result"].dict(),
                "fraud_detection": state["fraud_result"].dict(),
                "consistency": state["consistency_result"].dict()
            }, indent=2)
        })
        
        # Create the final result
        final_result = ClaimProcessingResult(
            claim_reference=state["claim_reference"],
            processing_timestamp=datetime.utcnow(),
            processing_steps=processing_steps,
            summary=summary.content
        )
        
        return {"final_result": final_result}
    
    # Add nodes to the graph
    workflow.add_node("extract_content", extract_content)
    workflow.add_node("validate_claim", validate_claim)
    workflow.add_node("detect_fraud", detect_fraud)
    workflow.add_node("verify_consistency", verify_consistency)
    workflow.add_node("merge_results", merge_results)
    
    # Define the edges
    workflow.add_edge("extract_content", "validate_claim")
    workflow.add_edge("validate_claim", "detect_fraud")
    workflow.add_edge("detect_fraud", "verify_consistency")
    workflow.add_edge("verify_consistency", "merge_results")
    
    # Set the entry point
    workflow.set_entry_point("extract_content")
    
    # Set the exit point
    workflow.set_finish_point("merge_results")
    
    return workflow.compile() 