from mcp.shared.exceptions import McpError
from mcp.types import ErrorData, INTERNAL_ERROR, INVALID_PARAMS

class ClaimProcessingError(McpError):
    """Base exception for claim processing errors."""
    pass

class ContentExtractionError(ClaimProcessingError):
    """Exception raised when content extraction fails."""
    def __init__(self, message: str):
        super().__init__(ErrorData(INTERNAL_ERROR, f"Content extraction failed: {message}"))

class ClaimValidationError(ClaimProcessingError):
    """Exception raised when claim validation fails."""
    def __init__(self, message: str):
        super().__init__(ErrorData(INVALID_PARAMS, f"Claim validation failed: {message}"))

class FraudDetectionError(ClaimProcessingError):
    """Exception raised when fraud detection fails."""
    def __init__(self, message: str):
        super().__init__(ErrorData(INTERNAL_ERROR, f"Fraud detection failed: {message}"))

class DataConsistencyError(ClaimProcessingError):
    """Exception raised when data consistency check fails."""
    def __init__(self, message: str):
        super().__init__(ErrorData(INVALID_PARAMS, f"Data consistency check failed: {message}"))

class ConfigurationError(ClaimProcessingError):
    """Exception raised when configuration is invalid."""
    def __init__(self, message: str):
        super().__init__(ErrorData(INTERNAL_ERROR, f"Configuration error: {message}")) 