import os
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
import uvicorn
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.routing import Route, Mount

from mcp.server.fastmcp import FastMCP
from mcp.server.sse import SseServerTransport

from src.core.config import Config
from src.services.content_extractor import extract_contents
from src.services.claim_validator import validate_claim_amount
from src.services.fraud_detector import detect_fraud
from src.services.data_consistency import verify_data_consistency

# Load environment variables
load_dotenv()

# Initialize configuration
config = Config()

# Initialize Azure OpenAI with LangChain
llm = AzureChatOpenAI(
    openai_api_version=config.azure_openai_config["api_version"],
    azure_deployment=config.azure_openai_config["deployment_name"],
    azure_endpoint=config.azure_openai_config["endpoint"],
    api_key=config.azure_openai_config["api_key"],
    temperature=0.7
)

# Initialize MCP server
mcp = FastMCP("claims_processor")

@mcp.tool()
def extract_contents_tool(url: str) -> str:
    """Extract the main content from a webpage using trafilatura library."""
    return extract_contents(url)

@mcp.tool()
def validate_claim_amount_tool(claim_data_path: str) -> str:
    """Validate the claimed amount against standard procedure costs."""
    return validate_claim_amount(claim_data_path, llm)

@mcp.tool()
def detect_fraud_tool(claim_data_path: str) -> str:
    """Detect potential fraud in a claim by analyzing historical data and provider information."""
    return detect_fraud(claim_data_path, llm)

@mcp.tool()
def verify_data_consistency_tool(portal_data_path: str, extracted_data_path: str) -> str:
    """Verify consistency between portal submission data and extracted document data."""
    return verify_data_consistency(portal_data_path, extracted_data_path, llm)

# Set up the SSE transport for MCP communication
sse = SseServerTransport("/messages/")

async def handle_sse(request: Request) -> None:
    _server = mcp._mcp_server
    async with sse.connect_sse(
        request.scope,
        request.receive,
        request._send,
    ) as (reader, writer):
        await _server.run(reader, writer, _server.create_initialization_options())

# Create the Starlette app with two endpoints:
# - "/sse": for SSE connections from clients
# - "/messages/": for handling incoming POST messages
app = Starlette(
    debug=config.server_config.get("debug", True),
    routes=[
        Route("/sse", endpoint=handle_sse),
        Mount("/messages/", app=sse.handle_post_message),
    ],
)

if __name__ == "__main__":
    server_config = config.server_config
    uvicorn.run(
        app,
        host=server_config.get("host", "localhost"),
        port=server_config.get("port", 8000)
    ) 