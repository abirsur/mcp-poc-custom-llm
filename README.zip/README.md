# Claims Processing System

A robust claims processing system that automates the validation, fraud detection, and consistency verification of insurance claims.

## Project Structure

```
claims_processing/
├── src/
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py           # Configuration management
│   │   ├── exceptions.py       # Custom exceptions
│   │   └── logging.py          # Logging configuration
│   ├── models/
│   │   ├── __init__.py
│   │   ├── base.py            # Base model classes
│   │   ├── claim.py           # Claim-related models
│   │   └── validation.py      # Validation result models
│   ├── services/
│   │   ├── __init__.py
│   │   ├── content_extractor.py
│   │   ├── claim_validator.py
│   │   ├── fraud_detector.py
│   │   └── data_consistency.py
│   ├── workflows/
│   │   ├── __init__.py
│   │   └── claim_processing.py
│   └── utils/
│       ├── __init__.py
│       ├── file_handlers.py
│       └── validators.py
├── tests/
│   ├── __init__.py
│   ├── conftest.py
│   ├── unit/
│   │   ├── __init__.py
│   │   ├── test_models/
│   │   ├── test_services/
│   │   └── test_workflows/
│   └── integration/
│       ├── __init__.py
│       └── test_workflows/
├── data/
│   ├── raw/                   # Original claim data
│   ├── processed/             # Processed results
│   ├── portal/               # Portal submission data
│   └── extracted/            # Extracted document data
├── logs/                     # Application logs
├── config/
│   ├── __init__.py
│   ├── development.yaml
│   ├── production.yaml
│   └── test.yaml
├── scripts/
│   ├── setup.sh
│   └── run_tests.sh
├── requirements/
│   ├── base.txt
│   ├── dev.txt
│   └── prod.txt
├── .env.example
├── .gitignore
├── setup.py
├── README.md
└── Makefile
```

## Features

- Content extraction from claim documents
- Claim amount validation against standard costs
- Fraud detection using historical data
- Data consistency verification
- Automated workflow processing
- Comprehensive logging and monitoring
- Configurable processing rules

## Installation

1. Clone the repository:
```bash
git clone https://github.com/your-org/claims-processing.git
cd claims-processing
```

2. Create and activate a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements/dev.txt
```

4. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your configuration
```

## Usage

1. Start the server:
```bash
python src/server.py
```

2. Process a claim:
```bash
python src/client.py http://localhost:8000/sse process_claim CLAIM-2024-001 \
    http://example.com/claim \
    data/raw/claim.json \
    data/portal/portal.json \
    data/extracted/extracted.json
```

## Development

1. Run tests:
```bash
make test
```

2. Run linting:
```bash
make lint
```

3. Run type checking:
```bash
make type-check
```

## Configuration

The system can be configured using YAML files in the `config/` directory:
- `development.yaml`: Development environment settings
- `production.yaml`: Production environment settings
- `test.yaml`: Test environment settings

## Logging

Logs are stored in the `logs/` directory with the following structure:
- `app.log`: Application logs
- `error.log`: Error logs
- `access.log`: Access logs

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.
