#!/usr/bin/env python3
"""
Test runner for the MCP Data Processing Client
"""

import asyncio
import logging
import os
import sys
from dotenv import load_dotenv
import uvicorn
from mcp_server import get_app
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def run_server():
    app = await get_app()
    config = uvicorn.Config(app, host="127.0.0.1", port=8080, log_level="info")
    server = uvicorn.Server(config)
    await server.serve()

async def run_test():
    """
    Initializes and runs the data processing client.
    """
    load_dotenv()
    
    server_task = asyncio.create_task(run_server())
    await asyncio.sleep(2)  # Give the server a moment to start

    logger.info(f"--- Starting Data Processing Test ---")

    try:
        from mcp_client import main as run_azure_processing
        if not os.getenv("AZURE_OPENAI_API_KEY") or not os.getenv("AZURE_OPENAI_ENDPOINT"):
            logger.error("Azure OpenAI environment variables not set.")
            logger.error("Please set AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT in your .env file.")
            return
            
        # Load data and config
        with open("extracted_data.json", "r") as f:
            extracted_data = json.load(f)
            
        with open("config.json", "r") as f:
            config = json.load(f)

        await run_azure_processing(config, extracted_data)
        logger.info("--- Azure Data Processing Test Completed Successfully ---")
    except Exception as e:
        logger.error(f"An error occurred during the test run: {e}", exc_info=True)
    finally:
        server_task.cancel()
        try:
            await server_task
        except asyncio.CancelledError:
            logger.info("Server task cancelled.")

if __name__ == "__main__":
    asyncio.run(run_test())
