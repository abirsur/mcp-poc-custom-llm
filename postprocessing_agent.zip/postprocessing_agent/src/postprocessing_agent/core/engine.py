from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from ..domain.models import FieldOperation, WorkflowConfig, WorkflowContext
from ..infrastructure.logging import get_logger, ticket_logging_context
from .operations import (
    APIEnrichmentOperation,
    ComprehensiveSelectionOperation,
    DependencyPropagationOperation,
    LLMEnhancementOperation,
    PrioritySelectionOperation,
    SimilarityMatchOperation,
)

LOGGER = get_logger("postprocessing_agent.core.engine")


@dataclass(slots=True)
class FieldExecutionState:
    """Mutable per-field state shared across pipeline operations."""

    field_path: str
    all_candidates: list[Any] = field(default_factory=list)
    active_candidates: list[Any] = field(default_factory=list)
    match_groups: list[Any] = field(default_factory=list)
    anchor_candidate: Any | None = None


class PostProcessingEngine:
    """Workflow orchestrator that executes configured field pipelines in order."""

    def __init__(self) -> None:
        """Register supported operation handlers."""
        self.operation_registry = {
            "similarity_match": SimilarityMatchOperation(),
            "comprehensive_selection": ComprehensiveSelectionOperation(),
            "priority_selection": PrioritySelectionOperation(),
            "dependency_propagation": DependencyPropagationOperation(),
            "llm_enhancement": LLMEnhancementOperation(),
            "api_enrichment": APIEnrichmentOperation(),
        }

    def execute(
        self,
        workflow: WorkflowConfig,
        sources: list,
        ticket_no: str = "-",
    ) -> WorkflowContext:
        """Execute the full workflow and return the final context snapshot."""
        with ticket_logging_context(ticket_no):
            LOGGER.info(
                "Starting workflow execution with %s fields and %s sources",
                len(workflow.fields),
                len(sources),
            )
            context = WorkflowContext(sources=sources)
            for field_path in self._resolve_field_order(workflow):
                self._execute_field(field_path, workflow, context)
            LOGGER.info(
                "Completed workflow execution with %s resolved fields and %s pending actions",
                len(context.resolved_fields),
                len(context.pending_actions),
            )
            return context

    def _execute_field(
        self,
        field_path: str,
        workflow: WorkflowConfig,
        context: WorkflowContext,
    ) -> None:
        """Execute all configured pipeline steps for a single field."""
        field_definition = workflow.fields[field_path]
        state = FieldExecutionState(field_path=field_path)
        LOGGER.info("Executing field pipeline for %s", field_path)
        for step in field_definition.pipeline:
            self._execute_pipeline_step(field_path, step, context, state)
            self._record_step_details(field_path, step, context, state)

    def _execute_pipeline_step(
        self,
        field_path: str,
        step: FieldOperation,
        context: WorkflowContext,
        state: FieldExecutionState,
    ) -> None:
        """Resolve and execute one pipeline operation for a field."""
        operation = self.operation_registry.get(step.operation)
        if operation is None:
            raise ValueError(f"Unsupported operation: {step.operation}")
        LOGGER.info("Running operation %s for field %s", step.operation, field_path)
        operation.execute(context, field_path, step.config, state)

    def _resolve_field_order(self, workflow: WorkflowConfig) -> list[str]:
        """Topologically order fields so dependencies are executed first."""
        ordered_fields = list(workflow.fields)
        resolved: list[str] = []
        seen: set[str] = set()
        visiting: set[str] = set()

        def visit(field_path: str) -> None:
            """Depth-first traversal helper with cycle detection."""
            if field_path in seen:
                return
            if field_path in visiting:
                raise ValueError(f"Cyclic dependency detected at field '{field_path}'.")
            visiting.add(field_path)
            parent = workflow.fields[field_path].depends_on
            if parent:
                visit(parent)
            visiting.remove(field_path)
            seen.add(field_path)
            resolved.append(field_path)

        for field_path in ordered_fields:
            visit(field_path)
        return resolved

    def _record_step_details(
        self,
        field_path: str,
        step: FieldOperation,
        context: WorkflowContext,
        state: FieldExecutionState,
    ) -> None:
        """Append detailed, field-wise step output for manual verification."""
        context.execution_log.append(
            {
                "operation": "pipeline_step_detail",
                "field_path": field_path,
                "step_type": step.operation,
                "step_config": step.config,
                "resolved_value": (
                    asdict(context.resolved_fields[field_path])
                    if field_path in context.resolved_fields
                    else None
                ),
                "active_candidates": [asdict(item) for item in state.active_candidates],
                "all_candidates": [asdict(item) for item in state.all_candidates],
                "match_groups": [asdict(group) for group in state.match_groups],
                "anchor_candidate": (
                    asdict(state.anchor_candidate) if state.anchor_candidate is not None else None
                ),
            }
        )
