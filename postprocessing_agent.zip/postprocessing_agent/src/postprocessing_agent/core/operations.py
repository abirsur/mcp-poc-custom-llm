from __future__ import annotations

from abc import ABC, abstractmethod
from difflib import SequenceMatcher
from typing import Any

from ..domain.models import FieldValue, MatchGroup, ResolvedField, WorkflowContext
from ..infrastructure.logging import get_logger

LOGGER = get_logger("postprocessing_agent.core.operations")


def get_nested_value(data: dict[str, Any], field_path: str) -> Any:
    """Return a field value from a flattened extracted-data payload."""
    return data.get(field_path)


def completeness_score(value: Any) -> int:
    """Compute a heuristic score that prefers richer and longer values."""
    if value is None:
        return 0
    text = str(value).strip()
    if not text:
        return 0
    compact = text.replace(" ", "")
    return len(compact) + len(text.split()) * 2


def normalize_for_similarity(value: Any) -> str:
    """Normalize text so similarity comparisons are case-insensitive and stable."""
    if value is None:
        return ""
    return "".join(ch.lower() for ch in str(value) if ch.isalnum() or ch.isspace()).strip()


def similarity_score(left: Any, right: Any) -> float:
    """Calculate a fuzzy similarity score between two values."""
    normalized_left = normalize_for_similarity(left)
    normalized_right = normalize_for_similarity(right)
    if not normalized_left or not normalized_right:
        return 0.0
    if normalized_left == normalized_right:
        return 1.0
    return SequenceMatcher(a=normalized_left, b=normalized_right).ratio()


def extract_field_values(context: WorkflowContext, field_path: str) -> list[FieldValue]:
    """Extract all non-empty candidate values for a field across all sources."""
    values: list[FieldValue] = []
    for source in context.sources:
        value = get_nested_value(source.extracted_data, field_path)
        if value not in (None, ""):
            values.append(
                FieldValue(
                    field_path=field_path,
                    source_type=source.source_type,
                    value=value,
                )
            )
    return values


def candidate_sort_key(item: FieldValue) -> tuple[int, str, str]:
    """Return deterministic sort order favoring more complete candidate values."""
    return (-completeness_score(item.value), str(item.value), item.source_type)


class Operation(ABC):
    """Abstract base class for all workflow operations."""

    @abstractmethod
    def execute(
        self,
        context: WorkflowContext,
        field_path: str,
        config: dict[str, Any],
        state: Any,
    ) -> None:
        """Execute operation logic and mutate the shared workflow context/state."""
        raise NotImplementedError


class SimilarityMatchOperation(Operation):
    """Group candidate field values by fuzzy similarity and pick active candidates."""

    def execute(
        self,
        context: WorkflowContext,
        field_path: str,
        config: dict[str, Any],
        state: Any,
    ) -> None:
        """Run similarity grouping using optional anchor candidate and threshold."""
        threshold = float(config.get("threshold", 0.8))
        state.all_candidates = state.all_candidates or extract_field_values(context, field_path)
        if not state.all_candidates:
            LOGGER.info("No candidates found for similarity matching on %s", field_path)
            return

        if state.anchor_candidate is not None:
            filtered = [
                item
                for item in state.all_candidates
                if similarity_score(state.anchor_candidate.value, item.value) >= threshold
            ]
            if state.anchor_candidate not in filtered:
                filtered.append(state.anchor_candidate)
            filtered = sorted(filtered, key=candidate_sort_key)
            groups = [
                MatchGroup(
                    field_path=field_path,
                    values=filtered,
                    average_score=(
                        sum(
                            similarity_score(state.anchor_candidate.value, item.value)
                            for item in filtered
                        )
                        / len(filtered)
                    ),
                )
            ]
            state.active_candidates = filtered
        else:
            groups = _build_similarity_groups(field_path, state.all_candidates, threshold)
            best_group = sorted(
                groups,
                key=lambda group: (
                    -len(group.values),
                    -group.average_score,
                    candidate_sort_key(group.values[0]),
                ),
            )[0]
            state.active_candidates = list(best_group.values)

        state.match_groups = groups
        context.match_groups[field_path] = groups
        context.execution_log.append(
            {
                "operation": "similarity_match",
                "field_path": field_path,
                "group_count": len(groups),
                "threshold": threshold,
            }
        )
        LOGGER.info(
            "Similarity match completed for %s with %s groups and %s active candidates",
            field_path,
            len(groups),
            len(state.active_candidates),
        )


class ComprehensiveSelectionOperation(Operation):
    """Resolve a field by choosing the most information-rich candidate value."""

    def execute(
        self,
        context: WorkflowContext,
        field_path: str,
        config: dict[str, Any],
        state: Any,
    ) -> None:
        """Select the best candidate by completeness and persist it as resolved."""
        candidates = state.active_candidates or state.all_candidates or extract_field_values(
            context, field_path
        )
        if not candidates:
            LOGGER.info("No candidates found for comprehensive selection on %s", field_path)
            return
        selected = sorted(candidates, key=candidate_sort_key)[0]
        context.resolved_fields[field_path] = ResolvedField(
            field_path=field_path,
            value=selected.value,
            source_type=selected.source_type,
            strategy="comprehensive_selection",
            lineage={
                "candidate_sources": [item.source_type for item in candidates],
                "score": completeness_score(selected.value),
            },
        )
        state.anchor_candidate = selected
        state.active_candidates = [selected]
        context.execution_log.append(
            {
                "operation": "comprehensive_selection",
                "field_path": field_path,
                "selected_source": selected.source_type,
            }
        )
        LOGGER.info(
            "Comprehensive selection resolved %s from source %s",
            field_path,
            selected.source_type,
        )


class PrioritySelectionOperation(Operation):
    """Resolve a field based on explicit source-priority order."""

    def execute(
        self,
        context: WorkflowContext,
        field_path: str,
        config: dict[str, Any],
        state: Any,
    ) -> None:
        """Choose the best candidate according to source priority and tie-breakers."""
        priorities = config.get("source_priority", [])
        priority_map = {source: index for index, source in enumerate(priorities)}
        state.all_candidates = state.all_candidates or extract_field_values(context, field_path)
        candidates = state.active_candidates or state.all_candidates
        if not candidates:
            LOGGER.info("No candidates found for priority selection on %s", field_path)
            return
        selected = sorted(
            candidates,
            key=lambda item: (
                priority_map.get(item.source_type, len(priority_map) + 1),
                *candidate_sort_key(item),
            ),
        )[0]
        context.resolved_fields[field_path] = ResolvedField(
            field_path=field_path,
            value=selected.value,
            source_type=selected.source_type,
            strategy="priority_selection",
            lineage={
                "source_priority": priorities,
                "candidate_sources": [item.source_type for item in candidates],
            },
        )
        state.anchor_candidate = selected
        state.active_candidates = [selected]
        context.execution_log.append(
            {
                "operation": "priority_selection",
                "field_path": field_path,
                "selected_source": selected.source_type,
            }
        )
        LOGGER.info(
            "Priority selection resolved %s from source %s",
            field_path,
            selected.source_type,
        )


class DependencyPropagationOperation(Operation):
    """Resolve a child field from the same source chosen for a parent field."""

    def execute(
        self,
        context: WorkflowContext,
        field_path: str,
        config: dict[str, Any],
        state: Any,
    ) -> None:
        """Copy child value from the resolved parent source when available."""
        parent = config["parent_field"]
        parent_resolution = context.resolved_fields.get(parent)
        if not parent_resolution or not parent_resolution.source_type:
            LOGGER.info(
                "Skipping dependency propagation for %s because parent %s is unresolved",
                field_path,
                parent,
            )
            return
        source = next(
            (item for item in context.sources if item.source_type == parent_resolution.source_type),
            None,
        )
        if source is None:
            LOGGER.info(
                "Skipping dependency propagation for %s because parent source was not found",
                field_path,
            )
            return
        child_value = get_nested_value(source.extracted_data, field_path)
        if child_value in (None, ""):
            LOGGER.info(
                "Skipping dependency propagation for %s because source %s had no value",
                field_path,
                source.source_type,
            )
            return
        context.resolved_fields[field_path] = ResolvedField(
            field_path=field_path,
            value=child_value,
            source_type=source.source_type,
            strategy="dependency_propagation",
            lineage={"parent_field": parent, "parent_source": source.source_type},
        )
        state.anchor_candidate = FieldValue(
            field_path=field_path,
            source_type=source.source_type,
            value=child_value,
        )
        state.active_candidates = [state.anchor_candidate]
        state.all_candidates = extract_field_values(context, field_path)
        context.execution_log.append(
            {
                "operation": "dependency_propagation",
                "parent_field": parent,
                "field_path": field_path,
                "selected_source": source.source_type,
            }
        )
        LOGGER.info(
            "Dependency propagation resolved %s from parent %s via source %s",
            field_path,
            parent,
            source.source_type,
        )


class LLMEnhancementOperation(Operation):
    """Queue an LLM action when a field still needs model-driven enrichment."""

    def execute(
        self,
        context: WorkflowContext,
        field_path: str,
        config: dict[str, Any],
        state: Any,
    ) -> None:
        """Create a pending LLM action from resolved prompt-supporting fields."""
        if field_path in context.resolved_fields:
            LOGGER.info("Skipping LLM enhancement for %s because it is already resolved", field_path)
            return
        prompt_fields = {
            supporting_field: context.resolved_fields[supporting_field].value
            for supporting_field in config.get("prompt_fields", [])
            if supporting_field in context.resolved_fields
        }
        if not prompt_fields:
            LOGGER.info("Skipping LLM enhancement for %s because prompt fields are unavailable", field_path)
            return
        context.pending_actions.append(
            {
                "operation": "llm_enhancement",
                "field_path": field_path,
                "status": "pending_provider",
                "prompt_fields": prompt_fields,
            }
        )
        context.execution_log.append(
            {
                "operation": "llm_enhancement",
                "field_path": field_path,
                "status": "pending_provider",
            }
        )
        LOGGER.info("Queued LLM enhancement for %s", field_path)


class APIEnrichmentOperation(Operation):
    """Queue an external API action for unresolved fields with required inputs."""

    def execute(
        self,
        context: WorkflowContext,
        field_path: str,
        config: dict[str, Any],
        state: Any,
    ) -> None:
        """Create a pending API action once request fields are fully resolved."""
        required_fields = config.get("request_fields", [])
        request_payload = {
            required_field: context.resolved_fields[required_field].value
            for required_field in required_fields
            if required_field in context.resolved_fields
        }
        if len(request_payload) != len(required_fields):
            LOGGER.info(
                "Skipping API enrichment for %s because required fields are unresolved",
                field_path,
            )
            return
        context.pending_actions.append(
            {
                "operation": "api_enrichment",
                "field_path": field_path,
                "target": config.get("name", field_path),
                "status": "pending_provider",
                "endpoint": config["endpoint"],
                "method": config.get("method", "GET"),
                "request_payload": request_payload,
                "response_mapping": config.get("response_mapping", {}),
            }
        )
        context.execution_log.append(
            {
                "operation": "api_enrichment",
                "field_path": field_path,
                "status": "pending_provider",
            }
        )
        LOGGER.info("Queued API enrichment for %s", field_path)


def _build_similarity_groups(
    field_path: str,
    values: list[FieldValue],
    threshold: float,
) -> list[MatchGroup]:
    """Cluster field values into match groups based on pairwise similarity."""
    groups: list[list[FieldValue]] = []
    for value in values:
        placed = False
        for group in groups:
            score = max(similarity_score(value.value, member.value) for member in group)
            if score >= threshold:
                group.append(value)
                placed = True
                break
        if not placed:
            groups.append([value])

    match_groups: list[MatchGroup] = []
    for group in groups:
        if len(group) == 1:
            average_score = 1.0
        else:
            scores: list[float] = []
            for index, left in enumerate(group):
                for right in group[index + 1 :]:
                    scores.append(similarity_score(left.value, right.value))
            average_score = sum(scores) / len(scores) if scores else 1.0
        match_groups.append(
            MatchGroup(
                field_path=field_path,
                values=sorted(group, key=candidate_sort_key),
                average_score=average_score,
            )
        )
    return match_groups
