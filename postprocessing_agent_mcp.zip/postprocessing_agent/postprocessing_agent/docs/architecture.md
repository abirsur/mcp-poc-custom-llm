# Application Layout

## Runtime Flow

1. Load workflow JSON from `tests/configs/workflows/<version>/`.
2. Load extracted input JSON from `tests/data/input/<version>/`.
3. Load response template JSON from `tests/configs/responses/<version>/`.
4. Execute pipeline in `src/postprocessing_agent/`.
5. Build output payload using response template shape.
6. Write run artifact to `tests/data/output/<version>/`.

## Current Versioning Pattern

- Input: `tests/data/input/v8/`, `tests/data/input/v9/`
- Workflow: `tests/configs/workflows/v8/`, `tests/configs/workflows/v9/`
- Response template: `tests/configs/responses/v8/`, `tests/configs/responses/v9/`
- Output: `tests/data/output/v8/`, `tests/data/output/v9/`

## Notes

- Keep Python implementation under `src/postprocessing_agent/`.
- Keep versioned JSON assets in `tests/configs` and `tests/data`.
- Response output is template-driven and supports object/list nested structures.
- Structured SOV risk object can remain nested and is flattened internally for field resolution.
- Runtime implementation is class-based (OOP): `AgentApplication`, `ResponsePayloadBuilder`, `WorkflowConfigLoader`, `SourceDataLoader`, `TaxonomyPayloadParser`, `LoggingManager`.
