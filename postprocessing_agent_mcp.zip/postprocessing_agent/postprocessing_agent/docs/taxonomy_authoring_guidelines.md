# Taxonomy Authoring Guidelines

## Goal

Use this guide to create new taxonomy field definitions and workflow configs that are consistent, testable, and production-ready.

## Versioning Rules (Mandatory)

- Create a new version folder for every schema-changing update.
- Keep workflow, response template, input sample, and output sample in the same version line.
- Do not overwrite previous version artifacts.

Required versioned layout:

- `tests/configs/workflows/v<version>/sample_workflow_<version>.json`
- `tests/configs/responses/v<version>/response_<version>.json`
- `tests/data/input/v<version>/extracted_data_<version>.json`
- `tests/data/output/v<version>/run_output_<version>.json`

## Naming Rules

- Field names must be `Pascal_Case` with underscore separators.
- Keep names domain-specific and stable over time.
- Prefer explicit names over abbreviations unless they are industry standard.
- Child fields should share a clear parent prefix.
- It is valid to introduce a new naming set in a new version (example: `Client_*` -> `Insured_*`), but workflow and response template must both be updated together.

Examples:

- `Client_Name`
- `Client_Street_Address`
- `Policy_Policy_Number`
- `Policy_Carrier_Name`

## Source Modeling Rules

- Define stable `source_type` values (for example `ACORD_125`, `BROKER`, `EMAIL`).
- Keep source names consistent across all input files and workflows.
- Ensure each source payload can be flattened into taxonomy keys.

## Field Definition Checklist

For each field in `fields`:

- Define `type` (`string`, `number`, `date`, etc.).
- Define a non-empty ordered `pipeline`.
- Add `depends_on` only when strict parent-child lineage is required.
- Add optional metadata only when downstream consumers need it.

## Response Template Mapping Rules

- Response template is the source of output shape.
- Each response leaf must contain at least:
  - `field_value`
  - `confidence_score`
  - `confidence_value`
  - `rationale`
- Leaf path maps to workflow field name using path-token capitalization.
  - Example: `insured.legal_name` -> `Insured_Legal_Name`
  - Example: `risk.building.id` -> `Risk_Building_Id`
- Keep nested `risk` object structure when source is SOV-style; do not flatten in response template.

## Operation Selection Guidelines

- Use `similarity_match` when multiple sources may express the same value with minor variations.
- Use `comprehensive_selection` when richer text should win.
- Use `priority_selection` when source trust order is explicit.
- Use `dependency_propagation` for child fields that must come from parent-resolved source.
- Use `llm_enhancement` only when deterministic extraction cannot resolve the field.
- Use `api_enrichment` when an external authoritative service is needed.

## Recommended Pipeline Patterns

1. Similar values, then trust order:

```json
[
  { "operation": "similarity_match", "threshold": 0.8 },
  { "operation": "priority_selection", "source_priority": ["ACORD_125", "BROKER", "EMAIL"] }
]
```

2. Richest free-text selection:

```json
[
  { "operation": "similarity_match", "threshold": 0.75 },
  { "operation": "comprehensive_selection" }
]
```

3. Parent-child propagation:

```json
[
  { "operation": "dependency_propagation", "parent_field": "Client_Name" }
]
```

4. Deferred external enrichment:

```json
[
  {
    "operation": "api_enrichment",
    "endpoint": "https://example.com/carrier",
    "method": "GET",
    "request_fields": ["Policy_Policy_Number"],
    "response_mapping": { "carrier_name": "Policy_Carrier_Name" }
  }
]
```

## JSON Template For New Taxonomies

```json
{
  "fields": {
    "Domain_Primary_Field": {
      "type": "string",
      "pipeline": [
        { "operation": "similarity_match", "threshold": 0.8 },
        { "operation": "priority_selection", "source_priority": ["SOURCE_A", "SOURCE_B"] }
      ]
    },
    "Domain_Child_Field": {
      "type": "string",
      "depends_on": "Domain_Primary_Field",
      "pipeline": [
        { "operation": "dependency_propagation", "parent_field": "Domain_Primary_Field" }
      ]
    }
  }
}
```

## Validation Before PR

- Field names follow naming convention.
- Every field has non-empty `pipeline`.
- All referenced fields exist.
- All operation names are supported.
- `api_enrichment.request_fields` is non-empty when used.
- `source_priority` includes only valid source types.
- Every response-template leaf has a corresponding workflow field.
- Versioned input/workflow/response/output paths are all present.
- At least one positive and one negative unit test exist for new behavior.

## Required Test Cases For New Taxonomy Packs

- Happy path: all key fields resolve.
- Missing source value: fallback behavior is correct.
- Dependency chain: child fields align with parent-selected source.
- Priority conflict: source order is respected.
- Similarity threshold edge: near-threshold values behave as expected.
- External action case: pending action generated when prerequisites are met.
- Response-template alignment: no unintended `null` leaves for expected fields.

## Review Rubric For Developers

Ask reviewers to confirm:

1. Business meaning of each field is unambiguous.
2. Pipeline order is justified and deterministic.
3. Data lineage is preserved in `ResolvedField.lineage`.
4. Config avoids source-specific hardcoding unless explicitly intended.
5. Changes are covered by tests and sample input/output.

## Handoff Instructions

When assigning taxonomy work to another developer, provide:

- The business domain and required output fields.
- Source inventory and trust priority.
- Known value-quality issues per source.
- Expected fallback rules.
- Required validation tests and acceptance criteria.

Use this sentence in tickets:

"Follow `docs/taxonomy_authoring_guidelines.md` and include workflow JSON, sample input, and unit tests for both success and failure paths."

## Developer Prompt Template

Use this prompt when assigning taxonomy work:

"Create version `vX` taxonomy assets under `tests/configs` and `tests/data`.  
1) Define workflow fields and pipelines.  
2) Define response template with leaf metadata (`field_value`, `confidence_score`, `confidence_value`, `rationale`).  
3) Ensure every response leaf maps to a workflow field.  
4) Keep SOV `risk` object nested if present.  
5) Add versioned input sample and produce versioned output by running the agent.  
6) Validate with unit tests and include run command + output path."
