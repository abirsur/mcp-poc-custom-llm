# Post-Processing Agent Documentation

## Purpose

The Post-Processing Agent reconciles taxonomy fields from multiple extracted sources and produces a normalized final output.

The engine is workflow-driven, so behavior is controlled by JSON configuration rather than hardcoded field logic.

## Project Structure

- `src/postprocessing_agent/agent/`: CLI entrypoint and runtime orchestration wrapper.
- `src/postprocessing_agent/core/`: Workflow parsing, operation implementations, and execution engine.
- `src/postprocessing_agent/domain/`: Data models and domain exceptions.
- `src/postprocessing_agent/infrastructure/`: I/O loading and logging utilities.
- `tests/configs/workflows/`: Versioned workflow configuration JSON files.
- `tests/configs/responses/`: Versioned output response templates.
- `tests/data/input/`: Versioned extracted-data input files.
- `tests/data/output/`: Versioned output artifacts generated during runs.
- `tests/`: Unit tests.

## Runtime Flow

1. CLI loads workflow config (`load_workflow_config`).
2. CLI loads extracted data (`load_sources_from_file`).
3. CLI loads response template (`--response-template` is required).
4. Engine resolves field execution order (dependency-aware).
5. Each field executes its configured pipeline operations.
6. Engine returns resolved fields, pending actions, and execution logs.
7. CLI maps resolved fields into the response template structure and writes output JSON.

## Main Concepts

- `WorkflowConfig`: Full set of field definitions.
- `FieldDefinition`: One field's type, optional dependency, and pipeline.
- `FieldOperation`: One operation step plus operation-specific config.
- `WorkflowContext`: Shared mutable run state.
- `ResolvedField`: Final selected field value with lineage metadata.
- `pending_actions`: Deferred LLM/API actions for provider-specific integration.

## OOP Components

- `AgentApplication` (`agent/app.py`): Class-based CLI orchestration.
- `ResponsePayloadBuilder` (`agent/app.py`): Builds output JSON from response template + workflow context.
- `WorkflowConfigLoader` (`core/config.py`): Class-based workflow parser/validator.
- `SourceDataLoader` (`infrastructure/io.py`): Class-based source-record loader.
- `TaxonomyPayloadParser` (`infrastructure/io.py`): Class-based extracted-data parser/flattening.
- `LoggingManager` (`infrastructure/logging.py`): Class-based logging setup and ticket context.

Backward-compatible function wrappers are still exported to avoid breaking existing imports.

## Supported Operations

- `similarity_match`: Groups candidates by fuzzy matching and selects active group.
- `comprehensive_selection`: Picks most complete/rich value.
- `priority_selection`: Picks by source priority order with deterministic tie-breaks.
- `dependency_propagation`: Copies child value from the resolved parent source.
- `llm_enhancement`: Queues LLM enrichment if unresolved and prompt fields are available.
- `api_enrichment`: Queues API enrichment if required request fields are resolved.

## Workflow JSON Contract

Top-level shape:

```json
{
  "fields": {
    "Field_Name": {
      "type": "string",
      "depends_on": "Parent_Field_Optional",
      "pipeline": [
        {
          "operation": "similarity_match",
          "threshold": 0.8
        },
        {
          "operation": "priority_selection",
          "source_priority": ["ACORD_125", "BROKER", "EMAIL"]
        }
      ]
    }
  }
}
```

Validation rules:

- `fields` must be a non-empty object.
- Every field must define non-empty `type` and non-empty `pipeline`.
- Every pipeline step must define `operation`.
- `depends_on`, `parent_field`, `prompt_fields`, and `request_fields` must reference known fields.
- Unsupported operation names fail validation.

## Input Data Contract

The loader supports both:

- Flat extracted fields as list entries:
  - `field_name`, `field_value`, `confidence_score`, `confidence_value`, optional `rationale`
- Nested object extracted fields (for example SOV risk/building/premises/loss objects):
  - Leaves contain `field_value`, `confidence_score`, `confidence_value`, optional `rationale`

Example mixed input shape:

```json
{
  "taxanomy_extracted_data": [
    {
      "source_type": "ACORD_125",
      "extracted_data": [
        {
          "field_name": "Client_Name",
          "field_value": "Sunrise Manufacturing LLC",
          "confidence_score": 0.96,
          "confidence_value": "HIGH"
        }
      ]
    },
    {
      "source_type": "SOV_DOCUMENT",
      "extracted_data": {
        "risk": {
          "building": [
            {
              "id": {
                "field_value": "BLDG-001",
                "confidence_score": 0.95,
                "confidence_value": "HIGH"
              }
            }
          ]
        }
      }
    }
  ]
}
```

The loader flattens input into taxonomy keys such as `Client_Name` and `Risk_Building_Id`.

## Running the Agent

```powershell
$env:PYTHONPATH='src'
python -m postprocessing_agent `
  --workflow tests/configs/workflows/v8/sample_workflow_v8_exact_structure.json `
  --data tests/data/input/v8/extracted_data_v8_exact_structure.json `
  --response-template tests/configs/responses/v8/response_v8_exact_structure.json `
  --ticket-no TICKET-123 `
  --output tests/data/output/v8/run_output_v8_exact_structure.json
```

Useful flags:

- `--workflow tests/configs/workflows/<version>/sample_workflow_*.json`
- `--data tests/data/input/<version>/extracted_data_*.json`
- `--response-template tests/configs/responses/<version>/response_*.json`
- `--output tests/data/output/<version>/run_output_*.json`
- `--log-level INFO`

## Logging

- Logging is stdout-based and includes `ticket_no` on every record.
- Use `ticket_logging_context` indirectly through engine execution.
- Entry-point return codes:
  - `0`: success
  - `1`: startup/config error
  - `2`: workflow execution error
  - `99`: unexpected failure

## Testing

```powershell
$env:PYTHONPATH='src'; python -m unittest
```

The suite validates pipeline behavior, dependency propagation, operation ordering, pending actions, and entrypoint error handling.

## Extending the System

To add a new operation:

1. Add operation name to `WorkflowConfigLoader.SUPPORTED_OPERATIONS`.
2. Implement an `Operation` subclass in `core/operations.py`.
3. Register the operation in `PostProcessingEngine.__init__`.
4. Add config validation rules in `core/config.py`.
5. Add unit tests for behavior and failure paths.
