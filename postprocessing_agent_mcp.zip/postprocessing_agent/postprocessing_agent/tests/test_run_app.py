from __future__ import annotations

import argparse
from pathlib import Path

from postprocessing_agent import run_agent


def build_parser() -> argparse.ArgumentParser:
    """Build CLI parser for manual app execution."""
    parser = argparse.ArgumentParser(
        description="Manual test runner: execute postprocessing app with provided inputs."
    )
    parser.add_argument(
        "--workflow",
        default="tests/configs/workflows/v8/sample_workflow_v8_exact_structure.json",
        help="Path to workflow JSON.",
    )
    parser.add_argument(
        "--data",
        default="tests/data/input/v8/extracted_data_v8_exact_structure.json",
        help="Path to extracted input JSON.",
    )
    parser.add_argument(
        "--response-template",
        default="tests/configs/responses/v8/response_v8_exact_structure.json",
        help="Path to response template JSON.",
    )
    parser.add_argument(
        "--output",
        default="tests/data/output/v8/run_output_manual_test.json",
        help="Path to write output JSON.",
    )
    parser.add_argument(
        "--ticket-no",
        default="MANUAL-TEST",
        help="Ticket number used in logs.",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        help="Log level for app execution.",
    )
    return parser


def main() -> int:
    """Execute app once with given CLI inputs."""
    args = build_parser().parse_args()
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    exit_code = run_agent(
        [
            "--workflow",
            args.workflow,
            "--data",
            args.data,
            "--response-template",
            args.response_template,
            "--output",
            args.output,
            "--ticket-no",
            args.ticket_no,
            "--log-level",
            args.log_level,
        ]
    )
    print(f"run_agent exit_code={exit_code}")
    print(f"output={output_path.resolve()}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())

