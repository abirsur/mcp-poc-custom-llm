from pathlib import Path
import json
import unittest

from postprocessing_agent import (
    PostProcessingEngine,
    configure_logging,
    load_sources_from_file,
    load_workflow_config,
    run_agent,
)


class PostProcessingEngineV8Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        configure_logging(level="INFO")

    def setUp(self) -> None:
        tests_root = Path(__file__).resolve().parent
        self.data_path = tests_root / "data" / "input" / "v8" / "extracted_data_v8_exact_structure.json"
        self.workflow_path = (
            tests_root / "configs" / "workflows" / "v8" / "sample_workflow_v8_exact_structure.json"
        )
        self.response_template_path = (
            tests_root / "configs" / "responses" / "v8" / "response_v8_exact_structure.json"
        )
        self.output_path = (
            tests_root / "data" / "output" / "v8" / "run_output_v8_exact_structure.json"
        )
        self.output_path.parent.mkdir(parents=True, exist_ok=True)

        self.sources = load_sources_from_file(self.data_path)
        self.workflow = load_workflow_config(self.workflow_path)
        self.engine = PostProcessingEngine()

    def test_v8_sources_load_and_include_sov_and_loss(self) -> None:
        source_types = {source.source_type for source in self.sources}
        self.assertIn("SOV_DOCUMENT", source_types)
        self.assertIn("LOSS_NOTICE", source_types)
        self.assertIn("Risk_Building_Id", self.sources[2].extracted_data)

    def test_v8_workflow_resolves_expected_fields(self) -> None:
        context = self.engine.execute(self.workflow, self.sources)

        self.assertEqual(context.resolved_fields["Client_Name"].source_type, "ACORD_125")
        self.assertEqual(context.resolved_fields["Risk_Building_Id"].value, "BLDG-001")
        self.assertEqual(
            context.resolved_fields["Risk_Building_Coverage_Property_Limit"].value,
            9000000,
        )
        self.assertEqual(context.resolved_fields["Loss_Damage_Total_Amount"].value, 415500)

    def test_v8_run_agent_writes_expected_object_response(self) -> None:
        exit_code = run_agent(
            [
                "--workflow",
                str(self.workflow_path),
                "--data",
                str(self.data_path),
                "--ticket-no",
                "VERIFY-V8-TEST",
                "--response-template",
                str(self.response_template_path),
                "--output",
                str(self.output_path),
            ]
        )
        self.assertEqual(exit_code, 0)

        payload = json.loads(self.output_path.read_text(encoding="utf-8"))
        extracted = payload["taxanomy_extracted_data"][0]["extracted_data"]
        self.assertEqual(extracted["risk"]["building"][0]["id"]["field_value"], "BLDG-001")
        self.assertEqual(
            extracted["risk"]["building"][0]["coverage"][0]["property_limit"]["field_value"],
            9000000,
        )
        self.assertEqual(
            extracted["risk"]["building"][0]["loss"][0]["damage"]["total_amount"]["field_value"],
            415500,
        )


if __name__ == "__main__":
    unittest.main()
