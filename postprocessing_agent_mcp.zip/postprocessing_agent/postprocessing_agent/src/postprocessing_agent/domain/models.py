from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


FieldPath = str


@dataclass(slots=True)
class SourceRecord:
    """One extracted source document and its flattened taxonomy data."""

    source_type: str
    extracted_data: dict[str, Any]
    field_details: dict[str, dict[str, Any]] = field(default_factory=dict)


@dataclass(slots=True)
class FieldValue:
    """A candidate value for a field from a specific source."""

    field_path: FieldPath
    source_type: str
    value: Any


@dataclass(slots=True)
class MatchGroup:
    """A similarity-based cluster of candidate values for one field."""

    field_path: FieldPath
    values: list[FieldValue]
    average_score: float


@dataclass(slots=True)
class ResolvedField:
    """Final chosen value for a field including strategy and lineage metadata."""

    field_path: FieldPath
    value: Any
    source_type: str | None
    strategy: str
    lineage: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class WorkflowContext:
    """Shared mutable context produced and updated during workflow execution."""

    sources: list[SourceRecord]
    resolved_fields: dict[FieldPath, ResolvedField] = field(default_factory=dict)
    match_groups: dict[FieldPath, list[MatchGroup]] = field(default_factory=dict)
    execution_log: list[dict[str, Any]] = field(default_factory=list)
    pending_actions: list[dict[str, Any]] = field(default_factory=list)


@dataclass(slots=True)
class FieldOperation:
    """A single operation and its config inside a field pipeline."""

    operation: str
    config: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class FieldDefinition:
    """Declarative definition of one taxonomy field and its processing pipeline."""

    path: FieldPath
    field_type: str
    pipeline: list[FieldOperation] = field(default_factory=list)
    depends_on: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class WorkflowConfig:
    """Top-level workflow model containing all field definitions."""

    fields: dict[FieldPath, FieldDefinition] = field(default_factory=dict)
