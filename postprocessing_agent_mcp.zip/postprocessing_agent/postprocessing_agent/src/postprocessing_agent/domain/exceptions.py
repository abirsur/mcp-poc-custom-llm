from __future__ import annotations


class PostProcessingAgentError(Exception):
    """Base exception for the post-processing agent."""


class AgentStartupError(PostProcessingAgentError):
    """Raised when the agent fails during startup or configuration loading."""


class AgentExecutionError(PostProcessingAgentError):
    """Raised when the agent fails during workflow execution."""
