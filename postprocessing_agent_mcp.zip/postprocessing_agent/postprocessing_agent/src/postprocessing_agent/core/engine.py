from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from ..domain.models import FieldOperation, FieldValue, MatchGroup, ResolvedField, WorkflowConfig, WorkflowContext
from ..infrastructure.logging import get_logger, ticket_logging_context
from ..mcp import MCPToolClient

LOGGER = get_logger("postprocessing_agent.core.engine")


@dataclass(slots=True)
class FieldExecutionState:
    """Mutable per-field state shared across pipeline operations."""

    field_path: str
    all_candidates: list[Any] = field(default_factory=list)
    active_candidates: list[Any] = field(default_factory=list)
    match_groups: list[Any] = field(default_factory=list)
    anchor_candidate: Any | None = None


class PostProcessingEngine:
    """Workflow orchestrator that executes configured field pipelines in order."""

    def __init__(self, *, mcp_client: MCPToolClient | None = None) -> None:
        """Register supported MCP-backed operation tools."""
        self.operation_registry = {
            "similarity_match",
            "comprehensive_selection",
            "priority_selection",
            "dependency_propagation",
            "llm_enhancement",
            "api_enrichment",
        }
        self.mcp_client = mcp_client or MCPToolClient()

    def execute(
        self,
        workflow: WorkflowConfig,
        sources: list,
        ticket_no: str = "-",
    ) -> WorkflowContext:
        """Execute the full workflow and return the final context snapshot."""
        with ticket_logging_context(ticket_no):
            LOGGER.info(
                "Starting workflow execution with %s fields and %s sources",
                len(workflow.fields),
                len(sources),
            )
            context = WorkflowContext(sources=sources)
            for field_path in self._resolve_field_order(workflow):
                self._execute_field(field_path, workflow, context)
            LOGGER.info(
                "Completed workflow execution with %s resolved fields and %s pending actions",
                len(context.resolved_fields),
                len(context.pending_actions),
            )
            return context

    def _execute_field(
        self,
        field_path: str,
        workflow: WorkflowConfig,
        context: WorkflowContext,
    ) -> None:
        """Execute all configured pipeline steps for a single field."""
        field_definition = workflow.fields[field_path]
        state = FieldExecutionState(field_path=field_path)
        LOGGER.info("Executing field pipeline for %s", field_path)
        for step in field_definition.pipeline:
            self._execute_pipeline_step(field_path, step, context, state)
            self._record_step_details(field_path, step, context, state)

    def _execute_pipeline_step(
        self,
        field_path: str,
        step: FieldOperation,
        context: WorkflowContext,
        state: FieldExecutionState,
    ) -> None:
        """Resolve and execute one pipeline operation for a field."""
        if step.operation not in self.operation_registry:
            raise ValueError(f"Unsupported operation: {step.operation}")
        LOGGER.info("Running operation %s for field %s", step.operation, field_path)
        response = self.mcp_client.execute_operation(
            operation=step.operation,
            field_path=field_path,
            config=step.config,
            state=self._serialize_state(state),
            sources=context.sources,
            resolved_fields={
                key: asdict(value)
                for key, value in context.resolved_fields.items()
            },
        )
        self._apply_mcp_response(field_path, response, context, state)

    def _serialize_state(self, state: FieldExecutionState) -> dict[str, Any]:
        """Convert dataclass-based mutable field state into a JSON-serializable payload."""
        return {
            "field_path": state.field_path,
            "all_candidates": [asdict(item) for item in state.all_candidates],
            "active_candidates": [asdict(item) for item in state.active_candidates],
            "match_groups": [asdict(item) for item in state.match_groups],
            "anchor_candidate": asdict(state.anchor_candidate) if state.anchor_candidate else None,
        }

    def _apply_mcp_response(
        self,
        field_path: str,
        response: dict[str, Any],
        context: WorkflowContext,
        state: FieldExecutionState,
    ) -> None:
        """Apply one MCP operation response back onto workflow context and state."""
        state_payload = response.get("state", {})
        state.all_candidates = [
            FieldValue(**item) for item in state_payload.get("all_candidates", [])
        ]
        state.active_candidates = [
            FieldValue(**item) for item in state_payload.get("active_candidates", [])
        ]
        state.match_groups = [
            MatchGroup(
                field_path=item["field_path"],
                values=[FieldValue(**candidate) for candidate in item.get("values", [])],
                average_score=item["average_score"],
            )
            for item in state_payload.get("match_groups", [])
        ]
        anchor_candidate = state_payload.get("anchor_candidate")
        state.anchor_candidate = FieldValue(**anchor_candidate) if anchor_candidate else None

        resolved_field = response.get("resolved_field")
        if isinstance(resolved_field, dict):
            context.resolved_fields[field_path] = ResolvedField(**resolved_field)

        match_groups = response.get("match_groups")
        if isinstance(match_groups, list):
            context.match_groups[field_path] = [
                MatchGroup(
                    field_path=item["field_path"],
                    values=[FieldValue(**candidate) for candidate in item.get("values", [])],
                    average_score=item["average_score"],
                )
                for item in match_groups
            ]

        context.pending_actions.extend(response.get("pending_actions", []))
        context.execution_log.extend(response.get("execution_log_entries", []))

    def _resolve_field_order(self, workflow: WorkflowConfig) -> list[str]:
        """Topologically order fields so dependencies are executed first."""
        ordered_fields = list(workflow.fields)
        resolved: list[str] = []
        seen: set[str] = set()
        visiting: set[str] = set()

        def visit(field_path: str) -> None:
            """Depth-first traversal helper with cycle detection."""
            if field_path in seen:
                return
            if field_path in visiting:
                raise ValueError(f"Cyclic dependency detected at field '{field_path}'.")
            visiting.add(field_path)
            parent = workflow.fields[field_path].depends_on
            if parent:
                visit(parent)
            visiting.remove(field_path)
            seen.add(field_path)
            resolved.append(field_path)

        for field_path in ordered_fields:
            visit(field_path)
        return resolved

    def _record_step_details(
        self,
        field_path: str,
        step: FieldOperation,
        context: WorkflowContext,
        state: FieldExecutionState,
    ) -> None:
        """Append detailed, field-wise step output for manual verification."""
        context.execution_log.append(
            {
                "operation": "pipeline_step_detail",
                "field_path": field_path,
                "step_type": step.operation,
                "step_config": step.config,
                "resolved_value": (
                    asdict(context.resolved_fields[field_path])
                    if field_path in context.resolved_fields
                    else None
                ),
                "active_candidates": [asdict(item) for item in state.active_candidates],
                "all_candidates": [asdict(item) for item in state.all_candidates],
                "match_groups": [asdict(group) for group in state.match_groups],
                "anchor_candidate": (
                    asdict(state.anchor_candidate) if state.anchor_candidate is not None else None
                ),
            }
        )
