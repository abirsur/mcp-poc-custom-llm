from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..domain.models import FieldDefinition, FieldOperation, WorkflowConfig
from ..infrastructure.logging import get_logger

LOGGER = get_logger("postprocessing_agent.core.config")


class WorkflowConfigLoader:
    """Class-based parser and validator for workflow configuration JSON."""

    SUPPORTED_OPERATIONS = {
        "similarity_match",
        "comprehensive_selection",
        "priority_selection",
        "dependency_propagation",
        "llm_enhancement",
        "api_enrichment",
    }

    def load(self, path: str | Path) -> WorkflowConfig:
        """Read a workflow JSON file and parse it into a validated config model."""
        LOGGER.info("Loading workflow config from %s", path)
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        return self.parse(payload)

    def parse(self, payload: dict[str, Any]) -> WorkflowConfig:
        """Validate and normalize a raw workflow dictionary into ``WorkflowConfig``."""
        if not isinstance(payload, dict):
            raise ValueError("Workflow config must be a JSON object.")

        raw_fields = payload.get("fields")
        if not isinstance(raw_fields, dict) or not raw_fields:
            raise ValueError("Workflow config must define a non-empty 'fields' object.")

        fields = self._parse_fields(raw_fields)
        self._validate_field_references(fields)
        LOGGER.info("Parsed workflow config with %s fields", len(fields))
        return WorkflowConfig(fields=fields)

    def _parse_fields(self, raw_fields: dict[str, Any]) -> dict[str, FieldDefinition]:
        """Parse all field definitions from the ``fields`` section."""
        fields: dict[str, FieldDefinition] = {}
        for field_path, definition in raw_fields.items():
            if not isinstance(definition, dict):
                raise ValueError(f"Field '{field_path}' must be an object.")
            field_type = definition.get("type")
            if not isinstance(field_type, str) or not field_type.strip():
                raise ValueError(f"Field '{field_path}' must define a non-empty string 'type'.")
            pipeline = self._parse_pipeline(field_path, definition.get("pipeline", []))
            depends_on = definition.get("depends_on")
            if depends_on is not None and not isinstance(depends_on, str):
                raise ValueError(f"Field '{field_path}' has an invalid 'depends_on' value.")

            metadata = {
                key: value
                for key, value in definition.items()
                if key not in {"type", "pipeline", "depends_on"}
            }
            fields[field_path] = FieldDefinition(
                path=field_path,
                field_type=field_type,
                pipeline=pipeline,
                depends_on=depends_on,
                metadata=metadata,
            )
        return fields

    def _parse_pipeline(self, field_path: str, raw_pipeline: Any) -> list[FieldOperation]:
        """Parse and validate ordered operations for a single field."""
        if not isinstance(raw_pipeline, list) or not raw_pipeline:
            raise ValueError(f"Field '{field_path}' must define a non-empty 'pipeline' list.")
        pipeline: list[FieldOperation] = []
        for index, raw_step in enumerate(raw_pipeline, start=1):
            if not isinstance(raw_step, dict):
                raise ValueError(f"Field '{field_path}' pipeline step {index} must be an object.")
            operation = raw_step.get("operation")
            if not isinstance(operation, str) or not operation.strip():
                raise ValueError(
                    f"Field '{field_path}' pipeline step {index} must define 'operation'."
                )
            self._validate_operation_names([operation], context=f"Field '{field_path}'")
            config = {key: value for key, value in raw_step.items() if key != "operation"}
            pipeline.append(FieldOperation(operation=operation, config=config))
        return pipeline

    def _validate_operation_names(self, operations: list[str], context: str) -> None:
        """Ensure all referenced operation names are supported by the engine."""
        unsupported = sorted(set(operations) - self.SUPPORTED_OPERATIONS)
        if unsupported:
            raise ValueError(
                f"{context} references unsupported operations: {', '.join(unsupported)}"
            )

    def _validate_field_references(self, fields: dict[str, FieldDefinition]) -> None:
        """Validate inter-field dependencies and operation-specific field references."""
        field_names = set(fields)

        for field in fields.values():
            if field.depends_on and field.depends_on not in field_names:
                raise ValueError(
                    f"Field '{field.path}' depends on unknown field '{field.depends_on}'."
                )
            for step in field.pipeline:
                self._validate_pipeline_step(field.path, step, field_names)

    def _validate_pipeline_step(
        self,
        field_path: str,
        step: FieldOperation,
        field_names: set[str],
    ) -> None:
        """Validate one operation step against expected config requirements."""
        if step.operation == "dependency_propagation":
            parent = step.config.get("parent_field")
            if not isinstance(parent, str):
                raise ValueError(
                    f"Field '{field_path}' dependency_propagation must define 'parent_field'."
                )
            self._ensure_known_fields([parent], field_names, f"Field '{field_path}'")

        if step.operation == "llm_enhancement":
            prompt_fields = step.config.get("prompt_fields", [])
            if not isinstance(prompt_fields, list):
                raise ValueError(f"Field '{field_path}' has an invalid 'prompt_fields' list.")
            self._ensure_known_fields(prompt_fields, field_names, f"Field '{field_path}'")

        if step.operation == "api_enrichment":
            request_fields = step.config.get("request_fields", [])
            if not isinstance(request_fields, list) or not request_fields:
                raise ValueError(
                    f"Field '{field_path}' api_enrichment must define non-empty 'request_fields'."
                )
            self._ensure_known_fields(request_fields, field_names, f"Field '{field_path}'")

    def _ensure_known_fields(
        self, field_paths: Any, field_names: set[str], context: str
    ) -> None:
        """Raise an error when referenced field paths are unknown or malformed."""
        unknown = sorted(
            field_path
            for field_path in field_paths
            if not isinstance(field_path, str) or field_path not in field_names
        )
        if unknown:
            raise ValueError(f"{context} references unknown fields: {', '.join(unknown)}")


_DEFAULT_LOADER = WorkflowConfigLoader()
SUPPORTED_OPERATIONS = WorkflowConfigLoader.SUPPORTED_OPERATIONS


def load_workflow_config(path: str | Path) -> WorkflowConfig:
    """Backward-compatible wrapper using class-based workflow loader."""
    return _DEFAULT_LOADER.load(path)


def parse_workflow_config(payload: dict[str, Any]) -> WorkflowConfig:
    """Backward-compatible wrapper using class-based workflow parser."""
    return _DEFAULT_LOADER.parse(payload)
