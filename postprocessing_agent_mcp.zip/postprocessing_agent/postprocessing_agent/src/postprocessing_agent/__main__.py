from __future__ import annotations

import sys

from .agent import run_agent


if __name__ == "__main__":
    raise SystemExit(run_agent(sys.argv[1:]))
