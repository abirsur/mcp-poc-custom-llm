from __future__ import annotations

import asyncio
import sys
from dataclasses import asdict
from importlib import import_module
from pathlib import Path
from typing import Any

from fastmcp import Client

from ..domain.models import SourceRecord
from ..infrastructure.logging import get_logger

LOGGER = get_logger("postprocessing_agent.mcp.client")


class MCPToolClient:
    """Synchronous wrapper for calling operation tools through a FastMCP client."""

    def __init__(self) -> None:
        """Resolve and cache the external MCP server instance."""
        self.operations_mcp_server = self._load_operations_server()

    def execute_operation(
        self,
        *,
        operation: str,
        field_path: str,
        config: dict[str, Any],
        state: dict[str, Any],
        sources: list[SourceRecord],
        resolved_fields: dict[str, dict[str, Any]],
    ) -> dict[str, Any]:
        """Execute one operation tool and return the structured response payload."""
        payload = {
            "field_path": field_path,
            "config": config,
            "state": state,
            "context": {
                "sources": [asdict(source) for source in sources],
                "resolved_fields": resolved_fields,
            },
        }

        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(self._execute_operation_async(operation=operation, payload=payload))
        raise RuntimeError("MCPToolClient.execute_operation cannot be called inside an active event loop.")

    async def _execute_operation_async(self, *, operation: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Async client call for one MCP operation tool."""
        async with Client(self.operations_mcp_server) as client:
            result = await client.call_tool(operation, arguments=payload)
        if result.is_error:
            raise RuntimeError(f"MCP tool '{operation}' returned an error result.")
        if not isinstance(result.data, dict):
            raise TypeError(f"MCP tool '{operation}' returned unsupported response type.")
        LOGGER.debug("Executed MCP tool %s for field %s", operation, payload.get("field_path"))
        return result.data

    def _load_operations_server(self) -> Any:
        """Load FastMCP server object from external mcpserver package."""
        module_name = "postprocessing_mcpserver.server"
        try:
            module = import_module(module_name)
        except ModuleNotFoundError:
            workspace_sibling_src = (
                Path(__file__).resolve().parents[4] / "postprocessing_mcpserver" / "src"
            )
            if workspace_sibling_src.exists():
                sys.path.insert(0, str(workspace_sibling_src))
                module = import_module(module_name)
            else:
                raise

        server = getattr(module, "OPERATIONS_MCP_SERVER", None)
        if server is None:
            raise RuntimeError(
                "External MCP server module does not expose OPERATIONS_MCP_SERVER."
            )
        return server
