from __future__ import annotations

import logging
import logging.config
from contextlib import contextmanager
from contextvars import ContextVar, Token
from dataclasses import dataclass
from typing import Iterator


@dataclass(slots=True)
class LoggingState:
    """Mutable state container used by logging infrastructure."""

    record_factory_installed: bool = False


class TicketMetadataFilter(logging.Filter):
    """Attach a ticket number to log records when one is not already present."""

    def filter(self, record: logging.LogRecord) -> bool:
        """Inject ``ticket_no`` into each record and allow it to be emitted."""
        if not hasattr(record, "ticket_no"):
            record.ticket_no = LoggingManager.current_ticket_no()
        return True


class LoggingManager:
    """OOP facade for ticket-aware logging configuration and context management."""

    _ticket_no_var: ContextVar[str] = ContextVar("postprocessing_ticket_no", default="-")
    _base_record_factory = logging.getLogRecordFactory()
    _state = LoggingState()

    @classmethod
    def configure(cls, level: str = "INFO") -> None:
        """Configure package logging to stdout with ticket-aware formatting."""
        cls._install_ticket_record_factory()
        logging.config.dictConfig(
            {
                "version": 1,
                "disable_existing_loggers": False,
                "filters": {
                    "ticket_metadata": {
                        "()": "postprocessing_agent.infrastructure.logging.TicketMetadataFilter",
                    }
                },
                "formatters": {
                    "standard": {
                        "format": (
                            "%(asctime)s | %(levelname)s | %(name)s | "
                            "ticket_no=%(ticket_no)s | %(message)s"
                        )
                    }
                },
                "handlers": {
                    "stdout": {
                        "class": "logging.StreamHandler",
                        "stream": "ext://sys.stdout",
                        "formatter": "standard",
                        "filters": ["ticket_metadata"],
                    }
                },
                "loggers": {
                    "postprocessing_agent": {
                        "level": level,
                        "handlers": ["stdout"],
                        "propagate": False,
                    }
                },
            }
        )

    @classmethod
    def get_logger(cls, name: str) -> logging.Logger:
        """Return a namespaced logger instance."""
        return logging.getLogger(name)

    @classmethod
    @contextmanager
    def ticket_context(cls, ticket_no: str) -> Iterator[None]:
        """Scope log emission so all records include the supplied ticket number."""
        token: Token[str] = cls._ticket_no_var.set(ticket_no)
        try:
            yield
        finally:
            cls._ticket_no_var.reset(token)

    @classmethod
    def current_ticket_no(cls) -> str:
        """Return the active ticket number from context-local logging state."""
        return cls._ticket_no_var.get()

    @classmethod
    def _install_ticket_record_factory(cls) -> None:
        """Install a global log-record factory that backfills ``ticket_no``."""
        if cls._state.record_factory_installed:
            return

        def factory(*args: object, **kwargs: object) -> logging.LogRecord:
            """Create log records that always include ticket metadata."""
            record = cls._base_record_factory(*args, **kwargs)
            if not hasattr(record, "ticket_no"):
                record.ticket_no = cls.current_ticket_no()
            return record

        logging.setLogRecordFactory(factory)
        cls._state.record_factory_installed = True


def configure_logging(level: str = "INFO") -> None:
    """Backward-compatible wrapper for class-based logging setup."""
    LoggingManager.configure(level=level)


def get_logger(name: str) -> logging.Logger:
    """Backward-compatible wrapper for class-based logger retrieval."""
    return LoggingManager.get_logger(name)


@contextmanager
def ticket_logging_context(ticket_no: str) -> Iterator[None]:
    """Backward-compatible wrapper for class-based ticket context."""
    with LoggingManager.ticket_context(ticket_no):
        yield


def get_current_ticket_no() -> str:
    """Backward-compatible wrapper for class-based ticket lookup."""
    return LoggingManager.current_ticket_no()
