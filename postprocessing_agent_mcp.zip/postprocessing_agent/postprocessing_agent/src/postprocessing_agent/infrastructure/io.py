from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..domain.models import SourceRecord
from .logging import get_logger

LOGGER = get_logger("postprocessing_agent.infrastructure.io")


class TaxonomyPayloadParser:
    """Parser that normalizes mixed extracted-data payload styles."""

    def parse_extracted_data(self, payload: Any) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
        """Parse extracted data supporting both legacy and field-entry formats."""
        if isinstance(payload, list):
            return self._parse_field_entries(payload)
        if isinstance(payload, dict):
            return self.flatten_taxonomy_payload_with_details(payload)
        return {}, {}

    def flatten_taxonomy_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Flatten nested taxonomy payload objects into underscore-delimited keys."""
        flattened, _ = self.flatten_taxonomy_payload_with_details(payload)
        return flattened

    def flatten_taxonomy_payload_with_details(
        self,
        payload: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
        """Flatten nested payload and capture optional confidence metadata per field."""
        flattened: dict[str, Any] = {}
        field_details: dict[str, dict[str, Any]] = {}
        self._flatten_into(payload, flattened, field_details, prefix=())
        LOGGER.debug("Flattened taxonomy payload into %s fields", len(flattened))
        return flattened, field_details

    def _flatten_into(
        self,
        payload: dict[str, Any],
        flattened: dict[str, Any],
        field_details: dict[str, dict[str, Any]],
        prefix: tuple[str, ...],
    ) -> None:
        """Recursively walk payload nodes and write flattened key/value pairs."""
        for key, value in payload.items():
            current_prefix = (*prefix, key)
            if isinstance(value, dict) and self._is_metadata_leaf(value):
                taxonomy_name = self._build_taxonomy_name(current_prefix)
                flattened[taxonomy_name] = value.get("field_value", value.get("value"))
                field_details[taxonomy_name] = {
                    "confidence_score": value.get("confidence_score"),
                    "confidence_value": value.get("confidence_value"),
                    "rationale": value.get("rationale"),
                }
                continue
            if isinstance(value, dict):
                self._flatten_into(value, flattened, field_details, current_prefix)
                continue
            if isinstance(value, list):
                self._flatten_list(value, flattened, field_details, current_prefix)
                continue
            flattened[self._build_taxonomy_name(current_prefix)] = value

    def _parse_field_entries(
        self,
        entries: list[Any],
    ) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
        """Parse new entry-style fields into flattened values plus confidence metadata."""
        flattened: dict[str, Any] = {}
        field_details: dict[str, dict[str, Any]] = {}
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            field_name = entry.get("field_name")
            if not isinstance(field_name, str) or not field_name.strip():
                continue
            flattened[field_name] = entry.get("field_value")
            field_details[field_name] = {
                "confidence_score": entry.get("confidence_score"),
                "confidence_value": entry.get("confidence_value"),
                "rationale": entry.get("rationale"),
            }
        return flattened, field_details

    def _is_metadata_leaf(self, value: dict[str, Any]) -> bool:
        """Return ``True`` when a dict represents a field value with confidence metadata."""
        return "field_value" in value or "value" in value

    def _flatten_list(
        self,
        values: list[Any],
        flattened: dict[str, Any],
        field_details: dict[str, dict[str, Any]],
        prefix: tuple[str, ...],
    ) -> None:
        """Flatten list nodes by recursively processing object items under the same prefix."""
        for item in values:
            if isinstance(item, dict):
                self._flatten_into(item, flattened, field_details, prefix)

    def _build_taxonomy_name(self, parts: tuple[str, ...]) -> str:
        """Build a taxonomy field name from normalized key parts."""
        return "_".join(self._normalize_taxonomy_part(part) for part in parts)

    def _normalize_taxonomy_part(self, part: str) -> str:
        """Convert key segments to ``Pascal_Case``-style token format."""
        return "_".join(token.capitalize() for token in part.split("_") if token)


class SourceDataLoader:
    """OOP loader for source records from extracted-data JSON files."""

    def __init__(self, parser: TaxonomyPayloadParser | None = None) -> None:
        """Initialize with a payload parser dependency."""
        self.parser = parser or TaxonomyPayloadParser()

    def load_sources_from_file(self, path: str | Path) -> list[SourceRecord]:
        """Load extracted source records from JSON and normalize taxonomy keys."""
        LOGGER.info("Loading extracted source data from %s", path)
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        records = payload.get("taxanomy_extracted_data", [])
        sources: list[SourceRecord] = []
        for record in records:
            extracted_data, field_details = self.parser.parse_extracted_data(
                record.get("extracted_data", {})
            )
            sources.append(
                SourceRecord(
                    source_type=record["source_type"],
                    extracted_data=extracted_data,
                    field_details=field_details,
                )
            )
        LOGGER.info("Loaded %s source records", len(sources))
        return sources


_DEFAULT_PARSER = TaxonomyPayloadParser()
_DEFAULT_SOURCE_LOADER = SourceDataLoader(parser=_DEFAULT_PARSER)


def load_sources_from_file(path: str | Path) -> list[SourceRecord]:
    """Backward-compatible wrapper using class-based source-data loader."""
    return _DEFAULT_SOURCE_LOADER.load_sources_from_file(path)


def parse_extracted_data(payload: Any) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    """Backward-compatible wrapper for class-based extracted-data parsing."""
    return _DEFAULT_PARSER.parse_extracted_data(payload)


def flatten_taxonomy_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """Backward-compatible wrapper for class-based payload flattening."""
    return _DEFAULT_PARSER.flatten_taxonomy_payload(payload)


def flatten_taxonomy_payload_with_details(
    payload: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    """Backward-compatible wrapper for class-based payload flattening + metadata."""
    return _DEFAULT_PARSER.flatten_taxonomy_payload_with_details(payload)
