from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Sequence

from ..core.config import load_workflow_config
from ..core.engine import PostProcessingEngine
from ..domain.exceptions import AgentExecutionError, AgentStartupError
from ..infrastructure.io import load_sources_from_file
from ..infrastructure.logging import configure_logging, get_logger

LOGGER = get_logger("postprocessing_agent.agent.app")


class ResponsePayloadBuilder:
    """Builder for mapping workflow context into the configured response structure."""

    def load_response_template(self, path: Path) -> dict[str, Any]:
        """Load the sample response template from disk."""
        return json.loads(path.read_text(encoding="utf-8"))

    def build_response_payload(
        self,
        template: dict[str, Any],
        *,
        context: Any,
        ticket_no: str,
    ) -> dict[str, Any]:
        """Fill template with resolved values, confidence details, and execution logs."""
        response = json.loads(json.dumps(template))
        details_by_source = self._build_details_index(context)
        extracted_template = self._extract_extracted_data_template(response)
        response["taxanomy_extracted_data"] = [
            {
                "source_type": "POSTPROCESSED",
                "extracted_data": self._build_extracted_data_payload(
                    template_extracted_data=extracted_template,
                    context=context,
                    details_by_source=details_by_source,
                ),
            }
        ]
        response["postprocessing_summary"] = {
            "ticket_no": ticket_no,
            "resolved_field_count": len(context.resolved_fields),
            "pending_action_count": len(context.pending_actions),
        }
        response["postprocessing_details"] = {
            "resolved_fields": {
                field_path: asdict(resolved_field)
                for field_path, resolved_field in context.resolved_fields.items()
            },
            "pending_actions": context.pending_actions,
            "execution_log": context.execution_log,
        }
        return response

    def _build_details_index(self, context: Any) -> dict[tuple[str, str], dict[str, Any]]:
        """Index source field metadata by ``(source_type, field_path)``."""
        details_by_source: dict[tuple[str, str], dict[str, Any]] = {}
        for source in context.sources:
            for field_name, details in source.field_details.items():
                details_by_source[(source.source_type, field_name)] = details
        return details_by_source

    def _extract_extracted_data_template(self, template: dict[str, Any]) -> Any:
        """Return extracted-data template node from the first template output record."""
        records = template.get("taxanomy_extracted_data")
        if not isinstance(records, list) or not records:
            return []
        first = records[0]
        if not isinstance(first, dict):
            return []
        return first.get("extracted_data", [])

    def _build_extracted_data_payload(
        self,
        *,
        template_extracted_data: Any,
        context: Any,
        details_by_source: dict[tuple[str, str], dict[str, Any]],
    ) -> Any:
        """Build extracted-data payload matching the configured template shape."""
        if isinstance(template_extracted_data, dict):
            return self._map_object_template(
                template_extracted_data,
                path_parts=(),
                context=context,
                details_by_source=details_by_source,
            )
        return self._build_resolved_field_entries(context, details_by_source)

    def _build_resolved_field_entries(
        self,
        context: Any,
        details_by_source: dict[tuple[str, str], dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Build one object per resolved field including confidence and lineage details."""
        entries: list[dict[str, Any]] = []
        for field_path in sorted(context.resolved_fields):
            resolved_field = context.resolved_fields[field_path]
            detail = details_by_source.get((resolved_field.source_type or "", field_path), {})
            entries.append(
                {
                    "field_name": field_path,
                    "field_value": resolved_field.value,
                    "confidence_score": detail.get("confidence_score"),
                    "confidence_value": detail.get("confidence_value"),
                    "rationale": detail.get("rationale"),
                    "selected_source_type": resolved_field.source_type,
                    "selection_strategy": resolved_field.strategy,
                }
            )
        return entries

    def _map_object_template(
        self,
        template_node: dict[str, Any],
        *,
        path_parts: tuple[str, ...],
        context: Any,
        details_by_source: dict[tuple[str, str], dict[str, Any]],
    ) -> dict[str, Any]:
        """Recursively map resolved fields to a nested object template."""
        mapped: dict[str, Any] = {}
        for key, value in template_node.items():
            current_path = (*path_parts, key)
            if isinstance(value, dict) and self._is_field_leaf_template(value):
                mapped[key] = self._build_object_leaf(
                    field_path=self._build_taxonomy_field_path(current_path),
                    template_leaf=value,
                    context=context,
                    details_by_source=details_by_source,
                )
                continue
            if isinstance(value, dict):
                mapped[key] = self._map_object_template(
                    value,
                    path_parts=current_path,
                    context=context,
                    details_by_source=details_by_source,
                )
                continue
            if isinstance(value, list):
                mapped[key] = self._map_list_template(
                    value,
                    path_parts=current_path,
                    context=context,
                    details_by_source=details_by_source,
                )
                continue
            mapped[key] = value
        return mapped

    def _build_object_leaf(
        self,
        *,
        field_path: str,
        template_leaf: dict[str, Any],
        context: Any,
        details_by_source: dict[tuple[str, str], dict[str, Any]],
    ) -> dict[str, Any]:
        """Build one object-style leaf using resolved values and metadata."""
        resolved_field, resolved_field_path = self._resolve_field_with_alias(field_path, context)
        detail: dict[str, Any] = {}
        if resolved_field is not None and resolved_field.source_type:
            detail = details_by_source.get((resolved_field.source_type, resolved_field_path), {})

        mapped = dict(template_leaf)
        mapped["field_value"] = getattr(resolved_field, "value", None)
        mapped["confidence_score"] = detail.get("confidence_score")
        mapped["confidence_value"] = detail.get("confidence_value")
        mapped["rationale"] = detail.get("rationale")
        mapped["selected_source_type"] = getattr(resolved_field, "source_type", None)
        mapped["selection_strategy"] = getattr(resolved_field, "strategy", None)
        return mapped

    def _is_field_leaf_template(self, node: dict[str, Any]) -> bool:
        """Return ``True`` when object node looks like a field metadata leaf."""
        field_markers = {"field_value", "confidence_score", "confidence_value", "rationale"}
        return bool(field_markers.intersection(node))

    def _build_taxonomy_field_path(self, parts: tuple[str, ...]) -> str:
        """Build flattened taxonomy field name from nested object path parts."""
        normalized: list[str] = []
        for part in parts:
            normalized.append("_".join(token.capitalize() for token in part.split("_") if token))
        return "_".join(normalized)

    def _map_list_template(
        self,
        template_items: list[Any],
        *,
        path_parts: tuple[str, ...],
        context: Any,
        details_by_source: dict[tuple[str, str], dict[str, Any]],
    ) -> list[Any]:
        """Map list templates while preserving the configured object structure."""
        if not template_items:
            return []
        mapped: list[Any] = []
        for item in template_items:
            if isinstance(item, dict):
                mapped.append(
                    self._map_object_template(
                        item,
                        path_parts=path_parts,
                        context=context,
                        details_by_source=details_by_source,
                    )
                )
                continue
            mapped.append(item)
        return mapped

    def _resolve_field_with_alias(self, field_path: str, context: Any) -> tuple[Any | None, str]:
        """Resolve a field by exact key first, then by supported aliases."""
        resolved = context.resolved_fields.get(field_path)
        if resolved is not None:
            return resolved, field_path

        aliases = self._build_alias_candidates(field_path)
        for alias in aliases:
            resolved = context.resolved_fields.get(alias)
            if resolved is not None:
                return resolved, alias
        return None, field_path

    def _build_alias_candidates(self, field_path: str) -> list[str]:
        """Build fallback field-path aliases for nested template shapes."""
        aliases: list[str] = []
        if field_path.startswith("Risk_Building_Coverage_"):
            aliases.append(field_path.replace("Risk_Building_", "", 1))
        if field_path.startswith("Risk_Building_Loss_"):
            aliases.append(field_path.replace("Risk_Building_", "", 1))
        return aliases


class AgentApplication:
    """Class-based CLI application orchestrator for the post-processing agent."""

    def __init__(
        self,
        *,
        engine: PostProcessingEngine | None = None,
        payload_builder: ResponsePayloadBuilder | None = None,
    ) -> None:
        """Initialize app with dependency-injectable engine and payload builder."""
        self.engine = engine or PostProcessingEngine()
        self.payload_builder = payload_builder or ResponsePayloadBuilder()

    def build_argument_parser(self) -> argparse.ArgumentParser:
        """Build and return CLI parser for running the agent process."""
        parser = argparse.ArgumentParser(description="Run the post-processing agent.")
        parser.add_argument(
            "--workflow",
            default="configs/workflows/sample_workflow.json",
            help="Path to the workflow configuration JSON file.",
        )
        parser.add_argument(
            "--data",
            default="data/input/extracted_data.json",
            help="Path to the extracted data JSON file.",
        )
        parser.add_argument(
            "--ticket-no",
            default="AGENT-RUN",
            help="Ticket number to attach to stdout logs.",
        )
        parser.add_argument(
            "--log-level",
            default="INFO",
            help="Logging level for stdout logs.",
        )
        parser.add_argument(
            "--output",
            help="Optional path to write the final execution result as JSON.",
        )
        parser.add_argument(
            "--response-template",
            required=True,
            help="Path to the JSON template describing the output response structure.",
        )
        return parser

    def run(self, argv: Sequence[str] | None = None, *, configure_logs: bool) -> int:
        """Run the agent and return process-style exit code."""
        parser = self.build_argument_parser()
        args = parser.parse_args(argv)

        if configure_logs:
            configure_logging(level=args.log_level.upper())

        try:
            result = self._run_workflow(
                workflow_path=Path(args.workflow),
                data_path=Path(args.data),
                ticket_no=args.ticket_no,
                response_template_path=Path(args.response_template),
            )
            if args.output:
                output_path = Path(args.output)
                output_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
                LOGGER.info("Wrote execution result to %s", output_path)
            return 0
        except AgentStartupError:
            LOGGER.exception("Agent startup failed")
            return 1
        except AgentExecutionError:
            LOGGER.exception("Agent execution failed")
            return 2
        except Exception:
            LOGGER.exception("Agent failed with an unexpected error")
            return 99

    def _run_workflow(
        self,
        workflow_path: Path,
        data_path: Path,
        ticket_no: str,
        response_template_path: Path,
    ) -> dict[str, object]:
        """Load inputs, execute workflow, and build serializable result payload."""
        try:
            LOGGER.info("Initializing post-processing agent")
            workflow = load_workflow_config(workflow_path)
            sources = load_sources_from_file(data_path)
        except Exception as exc:
            raise AgentStartupError(str(exc)) from exc

        try:
            context = self.engine.execute(workflow, sources, ticket_no=ticket_no)
        except Exception as exc:
            raise AgentExecutionError(str(exc)) from exc

        response_template = self.payload_builder.load_response_template(response_template_path)
        result = self.payload_builder.build_response_payload(
            template=response_template,
            context=context,
            ticket_no=ticket_no,
        )
        LOGGER.info(
            "Agent run completed with %s resolved fields and %s pending actions",
            len(context.resolved_fields),
            len(context.pending_actions),
        )
        return result


_DEFAULT_APP = AgentApplication()


def build_argument_parser() -> argparse.ArgumentParser:
    """Backward-compatible wrapper returning app CLI parser."""
    return _DEFAULT_APP.build_argument_parser()


def run_agent(argv: Sequence[str] | None = None) -> int:
    """Run the agent with logging configuration enabled."""
    return run_agent_with_options(argv=argv, configure_logs=True)


def run_agent_with_options(
    argv: Sequence[str] | None = None,
    *,
    configure_logs: bool,
) -> int:
    """Backward-compatible wrapper for class-based app execution."""
    return _DEFAULT_APP.run(argv=argv, configure_logs=configure_logs)
