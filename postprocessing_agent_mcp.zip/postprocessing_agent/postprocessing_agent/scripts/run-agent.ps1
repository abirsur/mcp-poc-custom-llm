param(
    [string]$TicketNo = "AGENT-RUN",
    [string]$Workflow = "configs/workflows/sample_workflow.json",
    [string]$Data = "data/input/extracted_data.json",
    [string]$Output = "",
    [string]$ResponseTemplate = "configs/sample_response.json"
)

$arguments = @(
    "-m", "postprocessing_agent",
    "--ticket-no", $TicketNo,
    "--workflow", $Workflow,
    "--data", $Data,
    "--response-template", $ResponseTemplate
)

if ($Output -ne "") {
    $arguments += @("--output", $Output)
}

python @arguments

