# Post-Processing Agent

This project contains a first-pass, configuration-driven post-processing engine for reconciling taxonomy fields across multiple extracted sources.

Operation execution now runs through a FastMCP server/client boundary:

- Each workflow operation is implemented in the separate `postprocessing_mcpserver` project.
- This repo keeps only the MCP client (`postprocessing_agent.mcp.client.MCPToolClient`).
- Non-operation orchestration (config loading, field ordering, payload shaping, CLI) remains inside the postprocessing agent app.

## What It Supports

- Similarity-based grouping across sources
- Comprehensive value selection for richer candidates
- Source-priority selection
- Parent-child dependency propagation for lineage consistency
- Deferred hooks for LLM enhancement and API enrichment

## Example

```python
from pathlib import Path

from postprocessing_agent import (
    configure_logging,
    load_workflow_config,
    load_sources_from_file,
    PostProcessingEngine,
)

data_path = Path("data/input/extracted_data.json")
workflow_path = Path("configs/workflows/sample_workflow.json")

configure_logging(level="INFO")
sources = load_sources_from_file(data_path)
workflow = load_workflow_config(workflow_path)

engine = PostProcessingEngine()
context = engine.execute(workflow, sources, ticket_no="TICKET-12345")

print(context.resolved_fields["Client_Name"])
print(context.pending_actions)
```

Every log is emitted to stdout and tagged with `ticket_no`, for example:

```text
2026-03-22 04:45:10,210 | INFO | postprocessing_agent.core.engine | ticket_no=TICKET-12345 | Starting workflow execution with 15 fields and 3 sources
```

## Agent Entry Point

This package can now run as an agent process with a main entrypoint:

```powershell
python -m postprocessing_agent --ticket-no TICKET-12345
```

Run the MCP server from the separate `postprocessing_mcpserver` project.

Optional arguments:

- `--workflow` to choose the workflow JSON
- `--data` to choose the extracted-data JSON
- `--log-level` to control stdout logging verbosity
- `--output` to write the final result to a JSON file

## Project Structure

```text
postprocessing_agent/
├─ src/postprocessing_agent/
│  ├─ agent/                      # Entry-point orchestration (CLI/app runner)
│  ├─ core/                       # Workflow config parsing + engine + operations
│  ├─ domain/                     # Dataclasses and domain exceptions
│  ├─ infrastructure/             # Logging + IO adapters
│  ├─ __init__.py                 # Public API exports
│  └─ __main__.py                 # python -m postprocessing_agent entrypoint
├─ tests/                         # Unit tests
├─ configs/workflows/             # Workflow JSON files
├─ data/input/                    # Input source payloads
├─ data/output/                   # Generated outputs
├─ docs/                          # Architecture and authoring guidelines
├─ scripts/                       # Local helper scripts
├─ pyproject.toml                 # Build and script entrypoints
└─ README.md
```

## Documentation

- `docs/application_documentation.md`: Full architecture, runtime flow, contracts, and extension notes.
- `docs/taxonomy_authoring_guidelines.md`: Instructions for creating and reviewing new taxonomy workflows.

Startup errors, execution errors, and unexpected exceptions are all captured at the top level and logged to stdout.

## Workflow Contract

The engine now reads field-centric workflow definitions from JSON. Each field defines its own type, optional dependency, and ordered `pipeline` of generic operations.

This means the user controls both:

- which operations a field uses
- the exact order they run in

Examples:

- `priority_selection -> similarity_match -> comprehensive_selection`
- `similarity_match -> priority_selection`
- `dependency_propagation -> llm_enhancement`

When `priority_selection` comes first, it establishes the anchor source/value and later `similarity_match` uses that anchor to find similar candidates from the other sources. When `similarity_match` comes first, it discovers the matching candidate set first, and a later `priority_selection` can refine the final choice if the field pipeline includes it.

## Design Notes

The workflow is field-centric and driven by per-field ordered `pipeline` entries. Each operation reads from and writes to a shared execution context, which stores resolved values, match groups, execution logs, and deferred external actions.

The current implementation intentionally keeps LLM and API integration provider-agnostic. Instead of making network calls directly, those steps produce `pending_actions` with all required metadata so real providers can be plugged in later without changing orchestration logic.
