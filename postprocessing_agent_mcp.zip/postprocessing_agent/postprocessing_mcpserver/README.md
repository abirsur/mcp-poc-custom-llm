# Postprocessing MCP Server

This project hosts FastMCP tools for postprocessing operations.

Run locally:

```powershell
poetry run python -m postprocessing_mcpserver
```

Default transport is Streamable HTTP:

- URL: `http://127.0.0.1:8000/mcp`
- Override with env vars: `MCP_TRANSPORT`, `MCP_HOST`, `MCP_PORT`, `MCP_PATH`, `MCP_STATELESS_HTTP`

Examples:

```powershell
# Streamable HTTP (default)
$env:MCP_TRANSPORT = "streamable-http"
$env:MCP_HOST = "0.0.0.0"
$env:MCP_PORT = "8000"
$env:MCP_PATH = "/mcp"
poetry run python -m postprocessing_mcpserver
```

```powershell
# Stdio transport
$env:MCP_TRANSPORT = "stdio"
poetry run python -m postprocessing_mcpserver
```
