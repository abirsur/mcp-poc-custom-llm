from __future__ import annotations

import logging
import os
from difflib import SequenceMatcher
from typing import Any

from fastmcp import FastMCP

LOGGER = logging.getLogger("postprocessing_mcpserver.server")
OPERATIONS_MCP_SERVER = FastMCP("postprocessing-operations")


def get_nested_value(data: dict[str, Any], field_path: str) -> Any:
    """Return a field value from a flattened extracted-data payload."""
    return data.get(field_path)


def completeness_score(value: Any) -> int:
    """Compute a heuristic score that prefers richer and longer values."""
    if value is None:
        return 0
    text = str(value).strip()
    if not text:
        return 0
    compact = text.replace(" ", "")
    return len(compact) + len(text.split()) * 2


def normalize_for_similarity(value: Any) -> str:
    """Normalize text so similarity comparisons are case-insensitive and stable."""
    if value is None:
        return ""
    return "".join(ch.lower() for ch in str(value) if ch.isalnum() or ch.isspace()).strip()


def similarity_score(left: Any, right: Any) -> float:
    """Calculate a fuzzy similarity score between two values."""
    normalized_left = normalize_for_similarity(left)
    normalized_right = normalize_for_similarity(right)
    if not normalized_left or not normalized_right:
        return 0.0
    if normalized_left == normalized_right:
        return 1.0
    return SequenceMatcher(a=normalized_left, b=normalized_right).ratio()


def extract_field_values(context: dict[str, Any], field_path: str) -> list[dict[str, Any]]:
    """Extract all non-empty candidate values for a field across all sources."""
    values: list[dict[str, Any]] = []
    for source in context.get("sources", []):
        value = get_nested_value(source.get("extracted_data", {}), field_path)
        if value not in (None, ""):
            values.append(
                {
                    "field_path": field_path,
                    "source_type": source.get("source_type", ""),
                    "value": value,
                }
            )
    return values


def candidate_sort_key(item: dict[str, Any]) -> tuple[int, str, str]:
    """Return deterministic sort order favoring more complete candidate values."""
    return (
        -completeness_score(item.get("value")),
        str(item.get("value")),
        item.get("source_type", ""),
    )


def _build_similarity_groups(
    field_path: str,
    values: list[dict[str, Any]],
    threshold: float,
) -> list[dict[str, Any]]:
    """Cluster field values into match groups based on pairwise similarity."""
    groups: list[list[dict[str, Any]]] = []
    for value in values:
        placed = False
        for group in groups:
            score = max(similarity_score(value.get("value"), member.get("value")) for member in group)
            if score >= threshold:
                group.append(value)
                placed = True
                break
        if not placed:
            groups.append([value])

    match_groups: list[dict[str, Any]] = []
    for group in groups:
        if len(group) == 1:
            average_score = 1.0
        else:
            scores: list[float] = []
            for index, left in enumerate(group):
                for right in group[index + 1 :]:
                    scores.append(similarity_score(left.get("value"), right.get("value")))
            average_score = sum(scores) / len(scores) if scores else 1.0
        match_groups.append(
            {
                "field_path": field_path,
                "values": sorted(group, key=candidate_sort_key),
                "average_score": average_score,
            }
        )
    return match_groups


def _empty_response(state: dict[str, Any]) -> dict[str, Any]:
    """Create the default MCP operation response payload."""
    return {
        "state": state,
        "resolved_field": None,
        "match_groups": None,
        "execution_log_entries": [],
        "pending_actions": [],
    }


@OPERATIONS_MCP_SERVER.tool(name="similarity_match")
def similarity_match_tool(
    field_path: str,
    config: dict[str, Any],
    state: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Group candidate values by similarity and pick active candidates."""
    response = _empty_response(state)
    threshold = float(config.get("threshold", 0.8))
    if not state.get("all_candidates"):
        state["all_candidates"] = extract_field_values(context, field_path)
    if not state.get("all_candidates"):
        LOGGER.info("No candidates found for similarity matching on %s", field_path)
        return response

    anchor_candidate = state.get("anchor_candidate")
    all_candidates = state.get("all_candidates", [])

    if anchor_candidate is not None:
        filtered = [
            item
            for item in all_candidates
            if similarity_score(anchor_candidate.get("value"), item.get("value")) >= threshold
        ]
        if anchor_candidate not in filtered:
            filtered.append(anchor_candidate)
        filtered = sorted(filtered, key=candidate_sort_key)
        groups = [
            {
                "field_path": field_path,
                "values": filtered,
                "average_score": (
                    sum(
                        similarity_score(anchor_candidate.get("value"), item.get("value"))
                        for item in filtered
                    )
                    / len(filtered)
                ),
            }
        ]
        state["active_candidates"] = filtered
    else:
        groups = _build_similarity_groups(field_path, all_candidates, threshold)
        best_group = sorted(
            groups,
            key=lambda group: (
                -len(group.get("values", [])),
                -float(group.get("average_score", 0.0)),
                candidate_sort_key(group["values"][0]),
            ),
        )[0]
        state["active_candidates"] = list(best_group.get("values", []))

    state["match_groups"] = groups
    response["match_groups"] = groups
    response["execution_log_entries"].append(
        {
            "operation": "similarity_match",
            "field_path": field_path,
            "group_count": len(groups),
            "threshold": threshold,
        }
    )
    LOGGER.info(
        "Similarity match completed for %s with %s groups and %s active candidates",
        field_path,
        len(groups),
        len(state.get("active_candidates", [])),
    )
    return response


@OPERATIONS_MCP_SERVER.tool(name="comprehensive_selection")
def comprehensive_selection_tool(
    field_path: str,
    config: dict[str, Any],
    state: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Resolve a field by choosing the most information-rich candidate value."""
    del config
    response = _empty_response(state)
    candidates = (
        state.get("active_candidates")
        or state.get("all_candidates")
        or extract_field_values(context, field_path)
    )
    if not candidates:
        LOGGER.info("No candidates found for comprehensive selection on %s", field_path)
        return response

    selected = sorted(candidates, key=candidate_sort_key)[0]
    response["resolved_field"] = {
        "field_path": field_path,
        "value": selected.get("value"),
        "source_type": selected.get("source_type"),
        "strategy": "comprehensive_selection",
        "lineage": {
            "candidate_sources": [item.get("source_type") for item in candidates],
            "score": completeness_score(selected.get("value")),
        },
    }
    state["anchor_candidate"] = selected
    state["active_candidates"] = [selected]
    response["execution_log_entries"].append(
        {
            "operation": "comprehensive_selection",
            "field_path": field_path,
            "selected_source": selected.get("source_type"),
        }
    )
    LOGGER.info(
        "Comprehensive selection resolved %s from source %s",
        field_path,
        selected.get("source_type"),
    )
    return response


@OPERATIONS_MCP_SERVER.tool(name="priority_selection")
def priority_selection_tool(
    field_path: str,
    config: dict[str, Any],
    state: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Resolve a field based on explicit source-priority order."""
    response = _empty_response(state)
    priorities = config.get("source_priority", [])
    priority_map = {source: index for index, source in enumerate(priorities)}
    if not state.get("all_candidates"):
        state["all_candidates"] = extract_field_values(context, field_path)
    candidates = state.get("active_candidates") or state.get("all_candidates", [])
    if not candidates:
        LOGGER.info("No candidates found for priority selection on %s", field_path)
        return response

    selected = sorted(
        candidates,
        key=lambda item: (
            priority_map.get(item.get("source_type"), len(priority_map) + 1),
            *candidate_sort_key(item),
        ),
    )[0]
    response["resolved_field"] = {
        "field_path": field_path,
        "value": selected.get("value"),
        "source_type": selected.get("source_type"),
        "strategy": "priority_selection",
        "lineage": {
            "source_priority": priorities,
            "candidate_sources": [item.get("source_type") for item in candidates],
        },
    }
    state["anchor_candidate"] = selected
    state["active_candidates"] = [selected]
    response["execution_log_entries"].append(
        {
            "operation": "priority_selection",
            "field_path": field_path,
            "selected_source": selected.get("source_type"),
        }
    )
    LOGGER.info(
        "Priority selection resolved %s from source %s",
        field_path,
        selected.get("source_type"),
    )
    return response


@OPERATIONS_MCP_SERVER.tool(name="dependency_propagation")
def dependency_propagation_tool(
    field_path: str,
    config: dict[str, Any],
    state: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Resolve a child field from the same source chosen for a parent field."""
    response = _empty_response(state)
    parent = config["parent_field"]
    parent_resolution = context.get("resolved_fields", {}).get(parent)
    if not parent_resolution or not parent_resolution.get("source_type"):
        LOGGER.info(
            "Skipping dependency propagation for %s because parent %s is unresolved",
            field_path,
            parent,
        )
        return response

    source = next(
        (
            item
            for item in context.get("sources", [])
            if item.get("source_type") == parent_resolution.get("source_type")
        ),
        None,
    )
    if source is None:
        LOGGER.info(
            "Skipping dependency propagation for %s because parent source was not found",
            field_path,
        )
        return response

    child_value = get_nested_value(source.get("extracted_data", {}), field_path)
    if child_value in (None, ""):
        LOGGER.info(
            "Skipping dependency propagation for %s because source %s had no value",
            field_path,
            source.get("source_type"),
        )
        return response

    response["resolved_field"] = {
        "field_path": field_path,
        "value": child_value,
        "source_type": source.get("source_type"),
        "strategy": "dependency_propagation",
        "lineage": {"parent_field": parent, "parent_source": source.get("source_type")},
    }
    state["anchor_candidate"] = {
        "field_path": field_path,
        "source_type": source.get("source_type"),
        "value": child_value,
    }
    state["active_candidates"] = [state["anchor_candidate"]]
    state["all_candidates"] = extract_field_values(context, field_path)
    response["execution_log_entries"].append(
        {
            "operation": "dependency_propagation",
            "parent_field": parent,
            "field_path": field_path,
            "selected_source": source.get("source_type"),
        }
    )
    LOGGER.info(
        "Dependency propagation resolved %s from parent %s via source %s",
        field_path,
        parent,
        source.get("source_type"),
    )
    return response


@OPERATIONS_MCP_SERVER.tool(name="llm_enhancement")
def llm_enhancement_tool(
    field_path: str,
    config: dict[str, Any],
    state: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Queue an LLM action when a field still needs model-driven enrichment."""
    response = _empty_response(state)
    resolved_fields = context.get("resolved_fields", {})
    if field_path in resolved_fields:
        LOGGER.info("Skipping LLM enhancement for %s because it is already resolved", field_path)
        return response

    prompt_fields = {
        supporting_field: resolved_fields[supporting_field]["value"]
        for supporting_field in config.get("prompt_fields", [])
        if supporting_field in resolved_fields
    }
    if not prompt_fields:
        LOGGER.info("Skipping LLM enhancement for %s because prompt fields are unavailable", field_path)
        return response

    response["pending_actions"].append(
        {
            "operation": "llm_enhancement",
            "field_path": field_path,
            "status": "pending_provider",
            "prompt_fields": prompt_fields,
        }
    )
    response["execution_log_entries"].append(
        {
            "operation": "llm_enhancement",
            "field_path": field_path,
            "status": "pending_provider",
        }
    )
    LOGGER.info("Queued LLM enhancement for %s", field_path)
    return response


@OPERATIONS_MCP_SERVER.tool(name="api_enrichment")
def api_enrichment_tool(
    field_path: str,
    config: dict[str, Any],
    state: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Queue an external API action for unresolved fields with required inputs."""
    response = _empty_response(state)
    required_fields = config.get("request_fields", [])
    resolved_fields = context.get("resolved_fields", {})
    request_payload = {
        required_field: resolved_fields[required_field]["value"]
        for required_field in required_fields
        if required_field in resolved_fields
    }
    if len(request_payload) != len(required_fields):
        LOGGER.info(
            "Skipping API enrichment for %s because required fields are unresolved",
            field_path,
        )
        return response

    response["pending_actions"].append(
        {
            "operation": "api_enrichment",
            "field_path": field_path,
            "target": config.get("name", field_path),
            "status": "pending_provider",
            "endpoint": config["endpoint"],
            "method": config.get("method", "GET"),
            "request_payload": request_payload,
            "response_mapping": config.get("response_mapping", {}),
        }
    )
    response["execution_log_entries"].append(
        {
            "operation": "api_enrichment",
            "field_path": field_path,
            "status": "pending_provider",
        }
    )
    LOGGER.info("Queued API enrichment for %s", field_path)
    return response


def run_operations_mcp_server() -> None:
    """Run the operation MCP server with transport selected from environment."""
    transport = os.getenv("MCP_TRANSPORT", "streamable-http").strip().lower()
    if transport == "stdio":
        OPERATIONS_MCP_SERVER.run(transport="stdio")
        return

    host = os.getenv("MCP_HOST", "127.0.0.1").strip() or "127.0.0.1"
    port = int(os.getenv("MCP_PORT", "8002"))
    path = os.getenv("MCP_PATH", "/mcp").strip() or "/mcp"
    stateless_http = os.getenv("MCP_STATELESS_HTTP", "true").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }

    if transport not in {"http", "sse", "streamable-http"}:
        raise ValueError(
            "Invalid MCP_TRANSPORT value. Use one of: stdio, http, sse, streamable-http."
        )

    OPERATIONS_MCP_SERVER.run(
        transport=transport,
        host=host,
        port=port,
        path=path,
        stateless_http=stateless_http,
    )
