from .server import run_operations_mcp_server


if __name__ == "__main__":
    run_operations_mcp_server()
