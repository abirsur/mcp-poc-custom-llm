# .NET Framework to .NET Core Converter

This project uses an AI-powered Python script to automate the conversion of a .NET Framework 4.0 web application to .NET Core 8. It leverages the LangChain library to interact with a Large Language Model (LLM) for code translation, Pydantic for data validation, and the `dotnet` CLI for project creation and validation.

## Prerequisites

1.  **Python 3.8+**: Ensure you have Python installed. You can download it from [python.org](https://www.python.org/downloads/).
2.  **.NET 8 SDK**: The script relies on the `dotnet` command-line interface (CLI) to create the new project structure and validate the converted code. Download it from the [official .NET website](https://dotnet.microsoft.com/download/dotnet/8.0).
3.  **Azure OpenAI Service**: The script is configured to use the Azure OpenAI service. You will need:
    *   An Azure subscription with access to the Azure OpenAI service.
    *   A deployed model (e.g., GPT-4).
    *   Your Azure OpenAI endpoint, API key, API version, and deployment name.

## Setup and Installation

1.  **Clone the repository or download the files.**

2.  **Install Python dependencies**:
    Open a terminal in the project directory and run the following command to install the required packages:
    ```bash
    pip install -r requirements.txt
    ```

3.  **Set up your environment variables**:
    Create a file named `.env` in the root of the project directory and populate it with your Azure OpenAI credentials. A template is provided, which you should edit with your actual details:
    ```
    # Azure OpenAI Credentials
    AZURE_OPENAI_API_KEY="your_azure_openai_api_key_here"
    AZURE_OPENAI_ENDPOINT="your_azure_openai_endpoint_here"
    AZURE_OPENAI_API_VERSION="2023-05-15" # Or your specific API version
    AZURE_OPENAI_DEPLOYMENT_NAME="your_deployment_name_here"
    ```
    The script uses `python-dotenv` to load these variables automatically.

## How to Run

1.  **Configure the Script**:
    Open the `net_converter.py` file and modify the following variables at the bottom of the file:
    *   `OLD_PROJECT_DIR`: Set this to the absolute or relative path of the .NET Framework 4.0 project you want to convert.
    *   `NEW_PROJECT_DIR`: Set this to the path where you want the new .NET Core 8 project to be created. This directory will be created by the script.

    **Example:**
    ```python
    if __name__ == "__main__":
        # --- CONFIGURATION ---
        OLD_PROJECT_DIR = "C:/Users/YourUser/Documents/LegacyWebApp"
        NEW_PROJECT_DIR = "./converted_net_core_app"
        # ...
    ```

2.  **Execute the Conversion Script**:
    Run the script from your terminal:
    ```bash
    python net_converter.py
    ```

## How It Works

1.  **Project Initialization**: The script first calls `dotnet new webapp` to create a new, empty .NET Core 8 project in the specified target directory. This provides a standard folder structure and solution file.
2.  **File Traversal**: It walks through every file and directory in your old project's source location.
3.  **Code Conversion**: For each `.cs` file it finds, it reads the content and sends it to the LLM via a carefully crafted prompt. The prompt instructs the AI to:
    *   Convert the code to .NET Core 8.
    *   Apply modern coding patterns (like Dependency Injection and async/await).
    *   Return *only* the raw C# code.
    *   Suggest a new file path suitable for a modern .NET Core project.
4.  **Code Validation & Regeneration**:
    *   The script saves the AI-generated code to the suggested new file path.
    *   It then runs `dotnet build` on the entire new project.
    *   If the build succeeds, the conversion for that file is considered successful.
    *   If the build fails, the script deletes the faulty file and retries the conversion up to a maximum number of attempts (default is 3). This gives the LLM a chance to correct its own errors.
5.  **Completion**: The process repeats for all C# files.
6.  **Reporting**: Throughout the entire process, a detailed log is generated at `conversion_report.log`. This file contains a timestamped record of every action, including which files were processed, which succeeded, and which failed (along with the corresponding error messages).

## Important Notes

*   **Conversion Log**: After running the script, be sure to check the `conversion_report.log` file. This log provides a complete trace of the conversion process and is essential for identifying which files, if any, require manual intervention.
*   **LLM Performance**: The quality of the conversion heavily depends on the LLM's capabilities. The script is set to use `gpt-4-turbo`, which is recommended for this kind of complex task.
*   **Prompt Engineering**: The prompt in `get_conversion_chain()` is critical. You may need to tweak it to better suit the specifics of your legacy codebase.
*   **Non-C# Files**: This script is designed to handle `.cs` files. You will need to manually handle other file types like `.aspx`, `.cshtml`, `Web.config`, static assets, etc. The script provides a solid foundation for the C# logic, which is often the most complex part of the migration.
*   **Build Errors**: If a file consistently fails conversion, the script will report it and move on. You will need to manually inspect and convert these problematic files. The build output in the console will provide clues as to why it failed.
