from typing import Optional, List, Dict
from pydantic import BaseModel, Field

class ExtractedDataModel(BaseModel):
    """Complete model for extracted claim data"""
    
    # 1. Claimant Information
    claimant_name: str = Field(description="Full name of the claimant")
    gender: str = Field(description="Gender of the claimant (Male/Female/Other)")
    age_or_dob: str = Field(description="Age or Date of Birth of the claimant")
    contact_info: Dict[str, str] = Field(description="Contact information including phone, email, and address")
    insurance_id: str = Field(description="Insurance ID or Policy Number")
    employer_name: str = Field(description="Name of the employer")

    # 2. Medical Details
    date_of_injury_illness: str = Field(description="Date when the injury or illness occurred")
    diagnosis: List[str] = Field(description="List of diagnoses (e.g., ACL Tear, Fracture, Influenza)")
    icd_10_codes: Optional[List[str]] = Field(description="ICD-10 codes for the diagnoses", default=None)
    treating_physician: str = Field(description="Name of the treating physician")
    hospital_clinic: str = Field(description="Name of the hospital or clinic")
    admission_date: Optional[str] = Field(description="Date of admission", default=None)
    discharge_date: Optional[str] = Field(description="Date of discharge", default=None)
    procedures: List[Dict[str, str]] = Field(description="List of procedures with their CPT codes")
    prescriptions: List[str] = Field(description="List of prescribed medications")

    # 3. Billing & Financials
    claimed_amount: float = Field(description="Amount claimed")
    total_billed_amount: float = Field(description="Total amount billed")
    copay: Optional[float] = Field(description="Copay amount", default=None)
    deductible: Optional[float] = Field(description="Deductible amount", default=None)
    out_of_pocket: Optional[float] = Field(description="Out-of-pocket amount", default=None)
    line_item_costs: Dict[str, float] = Field(description="Individual line-item costs")
    payment_method: str = Field(description="Method of payment")

    # 4. Claim Processing Metadata
    claim_id: str = Field(description="Unique identifier for the claim")
    submission_date: str = Field(description="Date when the claim was submitted")
    claim_type: str = Field(description="Type of claim (Accident/Illness/Maternity/etc.)")
    claim_status: str = Field(description="Current status of the claim")
    referral_number: Optional[str] = Field(description="Referral number if applicable", default=None)
    prior_authorization_number: Optional[str] = Field(description="Prior authorization number if applicable", default=None) 