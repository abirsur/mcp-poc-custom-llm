import json
import pytest
from models import ExtractedDataModel

def test_extracted_data_model():
    """Test the ExtractedDataModel with sample data"""
    # Load the sample data
    with open('test_extracted_data.json', 'r') as f:
        sample_data = json.load(f)
    
    # Create model instance from sample data
    model = ExtractedDataModel(**sample_data)
    
    # Test claimant information
    assert model.claimant_name == "John Doe"
    assert model.gender == "Male"
    assert model.age_or_dob == "1985-06-10"
    assert model.contact_info["phone"] == "123-456-7890"
    assert model.insurance_id == "INS-987654321"
    assert model.employer_name == "ABC Tech Pvt Ltd"
    
    # Test medical details
    assert model.date_of_injury_illness == "2025-04-01"
    assert len(model.diagnosis) == 2
    assert "ACL Tear" in model.diagnosis
    assert len(model.icd_10_codes) == 2
    assert model.treating_physician == "Dr. Emma Clark"
    assert model.hospital_clinic == "City Med Hospital"
    assert model.admission_date == "2025-04-02"
    assert model.discharge_date == "2025-04-06"
    assert len(model.procedures) == 2
    assert model.procedures[0]["name"] == "Knee Arthroscopy"
    assert len(model.prescriptions) == 3
    
    # Test billing information
    assert model.claimed_amount == 5800.00
    assert model.total_billed_amount == 6200.00
    assert model.copay == 1000.00
    assert model.deductible == 500.00
    assert model.out_of_pocket == 1500.00
    assert model.line_item_costs["Surgery"] == 4000.00
    assert model.payment_method == "Direct Deposit"
    
    # Test claim processing metadata
    assert model.claim_id == "CLM-100234"
    assert model.submission_date == "2025-05-01"
    assert model.claim_type == "Accident"
    assert model.claim_status == "Under Review"
    assert model.referral_number == "REF-889932"
    assert model.prior_authorization_number == "AUTH-223344"

def test_model_validation():
    """Test model validation with invalid data"""
    # Test with missing required field
    invalid_data = {
        "claimant_name": "John Doe",
        # Missing gender field
        "age_or_dob": "1985-06-10"
    }
    
    with pytest.raises(Exception):
        ExtractedDataModel(**invalid_data)
    
    # Test with invalid data type
    invalid_data = {
        "claimant_name": "John Doe",
        "gender": "Male",
        "age_or_dob": "1985-06-10",
        "claimed_amount": "not_a_number"  # Should be float
    }
    
    with pytest.raises(Exception):
        ExtractedDataModel(**invalid_data)

if __name__ == "__main__":
    pytest.main([__file__]) 