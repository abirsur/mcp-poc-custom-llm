from pydantic import BaseModel, Field
from typing import Dict, Any, Optional
from datetime import datetime
from enum import Enum

class ValidationResult(BaseModel):
    """Result of claim amount validation"""
    is_valid: bool
    score: float
    explanation: str
    details: Dict[str, Any]

class RiskLevel(str, Enum):
    """Risk levels for fraud detection"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

class FraudDetectionResult(BaseModel):
    """Result of fraud detection analysis"""
    risk_level: RiskLevel
    risk_score: float
    explanation: str
    details: Dict[str, Any]

class ConsistencyResult(BaseModel):
    """Result of data consistency verification"""
    consistency_score: float
    is_consistent: bool
    mismatches: Dict[str, Dict[str, Any]]
    explanation: str

class ProcessingStep(BaseModel):
    """Represents a single processing step in the workflow"""
    status: str
    timestamp: datetime
    results: Dict[str, Any]

class ClaimProcessingResult(BaseModel):
    """Final result of the claim processing workflow"""
    claim_reference: str
    processing_timestamp: datetime
    processing_steps: Dict[str, ProcessingStep]
    summary: str 