import os
from pathlib import Path
from typing import Dict, Any
import yaml
from dotenv import load_dotenv

class Config:
    """Configuration management for the claims processing system."""
    
    def __init__(self, env: str = "development"):
        """Initialize configuration.
        
        Args:
            env: Environment name (development/production/test)
        """
        self.env = env
        self.base_dir = Path(__file__).parent.parent.parent
        self.config_dir = self.base_dir / "config"
        self.data_dir = self.base_dir / "data"
        self.logs_dir = self.base_dir / "logs"
        
        # Load environment variables
        load_dotenv(self.base_dir / ".env")
        
        # Load configuration
        self.config = self._load_config()
        
        # Ensure directories exist
        self._ensure_directories()
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file."""
        config_file = self.config_dir / f"{self.env}.yaml"
        if not config_file.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_file}")
        
        with open(config_file, 'r') as f:
            config = yaml.safe_load(f)
        
        # Override with environment variables
        config["azure_openai"] = {
            "api_version": os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
            "deployment_name": os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
            "endpoint": os.getenv("AZURE_OPENAI_ENDPOINT"),
            "api_key": os.getenv("AZURE_OPENAI_API_KEY")
        }
        
        return config
    
    def _ensure_directories(self):
        """Ensure required directories exist."""
        directories = [
            self.data_dir / "raw",
            self.data_dir / "processed",
            self.data_dir / "portal",
            self.data_dir / "extracted",
            self.logs_dir
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value.
        
        Args:
            key: Configuration key
            default: Default value if key not found
            
        Returns:
            Configuration value
        """
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return default
            
            if value is None:
                return default
        
        return value
    
    @property
    def azure_openai_config(self) -> Dict[str, str]:
        """Get Azure OpenAI configuration."""
        return self.get("azure_openai", {})
    
    @property
    def server_config(self) -> Dict[str, Any]:
        """Get server configuration."""
        return self.get("server", {})
    
    @property
    def logging_config(self) -> Dict[str, Any]:
        """Get logging configuration."""
        return self.get("logging", {}) 