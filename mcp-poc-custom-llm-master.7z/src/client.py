import os
import json
from typing import Dict, Any, Optional
from datetime import datetime
import asyncio
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage

from src.core.config import settings
from src.workflows.claim_processing import create_claim_processing_graph
from src.models.validation import ClaimProcessingResult

class ClaimProcessingClient:
    def __init__(self, server_url: str):
        """Initialize the claim processing client"""
        self.server_url = server_url
        self.llm = AzureChatOpenAI(
            azure_deployment=settings.AZURE_OPENAI_DEPLOYMENT,
            openai_api_version=settings.AZURE_OPENAI_API_VERSION,
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            api_key=settings.AZURE_OPENAI_API_KEY
        )
        self._ensure_directories()
    
    def _ensure_directories(self):
        """Ensure required directories exist"""
        directories = [
            "data/claims",
            "data/portal",
            "data/extracted",
            "data/results"
        ]
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
    
    async def _get_tools(self) -> Dict[str, Any]:
        """Get available tools from the server"""
        # This would typically make an API call to the server
        # For now, we'll return mock tools
        return {
            "extract_contents_tool": lambda url: "Extracted content",
            "validate_claim_amount_tool": lambda path: {
                "is_valid": True,
                "score": 85.0,
                "explanation": "Claim amount is within acceptable range",
                "details": {}
            },
            "detect_fraud_tool": lambda path: {
                "risk_level": "low",
                "risk_score": 15.0,
                "explanation": "No significant fraud indicators found",
                "details": {}
            },
            "verify_data_consistency_tool": lambda portal_path, extracted_path: {
                "consistency_score": 95.0,
                "is_consistent": True,
                "mismatches": {},
                "explanation": "Data is consistent across sources"
            }
        }
    
    async def process_claim(
        self,
        claim_reference: str,
        url: str,
        claim_data_path: str,
        portal_data_path: str,
        extracted_data_path: str
    ) -> ClaimProcessingResult:
        """Process a claim using the workflow"""
        try:
            # Get tools
            tools = await self._get_tools()
            
            # Create workflow graph
            workflow = create_claim_processing_graph(self.llm, tools)
            
            # Initialize state
            initial_state = {
                "claim_reference": claim_reference,
                "url": url,
                "claim_data_path": claim_data_path,
                "portal_data_path": portal_data_path,
                "extracted_data_path": extracted_data_path
            }
            
            # Run workflow
            result = await workflow.ainvoke(initial_state)
            
            # Save result
            result_path = f"data/results/{claim_reference}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
            with open(result_path, "w") as f:
                json.dump(result["final_result"].dict(), f, indent=2, default=str)
            
            return result["final_result"]
            
        except Exception as e:
            raise Exception(f"Error processing claim: {str(e)}")

async def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Process a claim")
    parser.add_argument("--server", required=True, help="Server URL")
    parser.add_argument("--claim-ref", required=True, help="Claim reference number")
    parser.add_argument("--url", required=True, help="URL to process")
    parser.add_argument("--claim-data", required=True, help="Path to claim data")
    parser.add_argument("--portal-data", required=True, help="Path to portal data")
    parser.add_argument("--extracted-data", required=True, help="Path to extracted data")
    
    args = parser.parse_args()
    
    client = ClaimProcessingClient(args.server)
    result = await client.process_claim(
        claim_reference=args.claim_ref,
        url=args.url,
        claim_data_path=args.claim_data,
        portal_data_path=args.portal_data,
        extracted_data_path=args.extracted_data
    )
    
    print(f"Claim processing completed. Result saved to: {result}")

if __name__ == "__main__":
    asyncio.run(main()) 