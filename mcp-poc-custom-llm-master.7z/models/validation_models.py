from pydantic import BaseModel, Field
from typing import List, Dict

class ValidationResult(BaseModel):
    """Model for claim validation results"""
    score: int = Field(description="Validation score (0-100)")
    is_valid: bool = Field(description="Whether the claim is valid")
    explanation: str = Field(description="Explanation of the validation result")
    procedure_code: str = Field(description="CPT code used for validation")
    standard_cost: float = Field(description="Standard cost for the procedure")
    deviation_percentage: float = Field(description="Percentage deviation from standard cost")

class FraudDetectionResult(BaseModel):
    """Model for fraud detection results"""
    score: int = Field(description="Fraud detection score (0-100)")
    risk_level: str = Field(description="Risk level (Low/Medium/High)")
    explanation: str = Field(description="Explanation of the fraud detection result")
    red_flags: List[str] = Field(description="List of identified red flags")
    provider_status: str = Field(description="Provider's current status")
    similar_claims: List[Dict] = Field(description="List of similar past claims")

class ConsistencyResult(BaseModel):
    """Model for data consistency verification results"""
    score: int = Field(description="Consistency score (0-100)")
    is_consistent: bool = Field(description="Whether the data is consistent")
    explanation: str = Field(description="Explanation of the consistency check result")
    mismatches: List[Dict[str, str]] = Field(description="List of identified mismatches")
    critical_mismatches: List[str] = Field(description="List of critical mismatches") 