import asyncio
import sys
import traceback
import os
from urllib.parse import urlparse
from typing import Optional, Dict, Any
import json
from datetime import datetime

from mcp import ClientSession
from mcp.client.sse import sse_client
from langchain_openai import AzureChatOpenAI
from tools.claim_processing_graph import create_claim_processing_graph

def ensure_directories():
    """Ensure required directories exist"""
    directories = [
        "claims",
        "claims/processed",
        "claims/raw",
        "claims/portal",
        "claims/extracted"
    ]
    for directory in directories:
        os.makedirs(directory, exist_ok=True)

def print_items(name: str, result: any) -> None:
    """Print items with formatting.

    Args:
        name: Category name (tools/resources/prompts)
        result: Result object containing items list
    """
    print(f"\nAvailable {name}:")
    items = getattr(result, name)
    if items:
        for item in items:
            print(" *", item)
    else:
        print("No items available")

async def process_claim(session: ClientSession, claim_reference: str, url: str, 
                       claim_data_path: str, portal_data_path: str, 
                       extracted_data_path: str) -> Dict[str, Any]:
    """Process a claim using the LangGraph workflow.
    
    Args:
        session: MCP client session
        claim_reference: Unique reference number for the claim
        url: URL to extract content from
        claim_data_path: Path to claim data JSON file
        portal_data_path: Path to portal submission data JSON file
        extracted_data_path: Path to extracted document data JSON file
        
    Returns:
        Dict containing the final analysis results
    """
    try:
        # Create tool functions
        async def extract_contents_tool(url: str) -> str:
            response = await session.call_tool("extract_contents_tool", {"url": url})
            return response
            
        async def validate_claim_amount_tool(claim_data_path: str) -> str:
            response = await session.call_tool("validate_claim_amount_tool", {"claim_data_path": claim_data_path})
            return response
            
        async def detect_fraud_tool(claim_data_path: str) -> str:
            response = await session.call_tool("detect_fraud_tool", {"claim_data_path": claim_data_path})
            return response
            
        async def verify_data_consistency_tool(portal_data_path: str, extracted_data_path: str) -> str:
            response = await session.call_tool(
                "verify_data_consistency_tool",
                {
                    "portal_data_path": portal_data_path,
                    "extracted_data_path": extracted_data_path
                }
            )
            return response
        
        # Initialize Azure OpenAI
        llm = AzureChatOpenAI(
            openai_api_version="2024-02-15-preview",
            azure_deployment="gpt-4",
            azure_endpoint="https://your-endpoint.openai.azure.com/",
            api_key="your-api-key",
            temperature=0.7
        )
        
        # Create the workflow graph
        tools = {
            "extract_contents_tool": extract_contents_tool,
            "validate_claim_amount_tool": validate_claim_amount_tool,
            "detect_fraud_tool": detect_fraud_tool,
            "verify_data_consistency_tool": verify_data_consistency_tool
        }
        
        graph = create_claim_processing_graph(llm, tools)
        
        # Initialize the state
        initial_state = {
            "claim_reference": claim_reference,
            "url": url,
            "claim_data_path": claim_data_path,
            "portal_data_path": portal_data_path,
            "extracted_data_path": extracted_data_path,
            "processing_timestamp": datetime.utcnow().isoformat()
        }
        
        # Run the workflow
        final_state = await graph.ainvoke(initial_state)
        
        return final_state["final_result"]
        
    except Exception as e:
        print(f"Error processing claim {claim_reference}: {e}")
        traceback.print_exception(type(e), e, e.__traceback__)
        raise

async def main(server_url: str, operation: str = None, *args):
    """Connect to the MCP server and perform operations.

    Args:
        server_url: Full URL to SSE endpoint (e.g. http://localhost:8000/sse)
        operation: The operation to perform (process_claim)
        args: Additional arguments for the operation
    """
    if urlparse(server_url).scheme not in ("http", "https"):
        print("Error: Server URL must start with http:// or https://")
        sys.exit(1)

    try:
        # Ensure required directories exist
        ensure_directories()
        
        async with sse_client(server_url) as streams:
            async with ClientSession(streams[0], streams[1]) as session:
                await session.initialize()
                print("Connected to MCP server at", server_url)
                print_items("tools", await session.list_tools())
                print_items("resources", await session.list_resources())
                print_items("prompts", await session.list_prompts())

                if operation == "process_claim":
                    if len(args) < 5:
                        print("Error: process_claim operation requires claim_reference, url, claim_data_path, portal_data_path, and extracted_data_path")
                        return
                    
                    claim_reference, url, claim_data_path, portal_data_path, extracted_data_path = args
                    result = await process_claim(
                        session,
                        claim_reference,
                        url,
                        claim_data_path,
                        portal_data_path,
                        extracted_data_path
                    )
                    
                    print(f"\n=== Claim Processing Results for {claim_reference} ===\n")
                    print(json.dumps(result, indent=2))
                    
                else:
                    print(f"Error: Unknown operation '{operation}'")

    except Exception as e:
        print(f"Error connecting to server: {e}")
        traceback.print_exception(type(e), e, e.__traceback__)
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(
            "Usage: python client.py <server_url> [<operation> <args...>]\n"
            "Operations:\n"
            "  process_claim <claim_reference> <url> <claim_data_path> <portal_data_path> <extracted_data_path>  - Process a claim\n"
            "\nExamples:\n"
            "  python client.py http://localhost:8000/sse process_claim CLAIM-2024-001 http://example.com/claim claims/raw/claim.json claims/portal/portal.json claims/extracted/extracted.json"
        )
        sys.exit(1)

    server_url = sys.argv[1]
    operation = sys.argv[2] if len(sys.argv) > 2 else None
    args = sys.argv[3:] if len(sys.argv) > 3 else []
    asyncio.run(main(server_url, operation, *args))
