import os
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
import uvicorn
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.routing import Route, Mount

from mcp.server.fastmcp import FastMCP
from mcp.server.sse import SseServerTransport

from tools.content_extractor import extract_contents
from tools.claim_validator import validate_claim_amount
from tools.fraud_detector import detect_fraud
from tools.data_consistency import verify_data_consistency

# Load environment variables
load_dotenv()

# Initialize Azure OpenAI with LangChain
llm = AzureChatOpenAI(
    openai_api_version="2024-02-15-preview",
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=0.7
)

mcp = FastMCP("content_extractor")

@mcp.tool()
def extract_contents_tool(url: str) -> str:
    """Extract the main content from a webpage using trafilatura library."""
    return extract_contents(url)

@mcp.tool()
def validate_claim_amount_tool(claim_data_path: str) -> str:
    """Validate the claimed amount against standard procedure costs."""
    return validate_claim_amount(claim_data_path, llm)

@mcp.tool()
def detect_fraud_tool(claim_data_path: str) -> str:
    """Detect potential fraud in a claim by analyzing historical data and provider information."""
    return detect_fraud(claim_data_path, llm)

@mcp.tool()
def verify_data_consistency_tool(portal_data_path: str, extracted_data_path: str) -> str:
    """Verify consistency between portal submission data and extracted document data."""
    return verify_data_consistency(portal_data_path, extracted_data_path, llm)

# Set up the SSE transport for MCP communication.
sse = SseServerTransport("/messages/")

async def handle_sse(request: Request) -> None:
    _server = mcp._mcp_server
    async with sse.connect_sse(
        request.scope,
        request.receive,
        request._send,
    ) as (reader, writer):
        await _server.run(reader, writer, _server.create_initialization_options())

# Create the Starlette app with two endpoints:
# - "/sse": for SSE connections from clients.
# - "/messages/": for handling incoming POST messages.
app = Starlette(
    debug=True,
    routes=[
        Route("/sse", endpoint=handle_sse),
        Mount("/messages/", app=sse.handle_post_message),
    ],
)

if __name__ == "__main__":
    uvicorn.run(app, host="localhost", port=8000)
