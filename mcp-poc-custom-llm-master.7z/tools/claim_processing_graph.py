from typing import Dict, List, Any, TypedDict
from langgraph.graph import Graph, StateGraph
from langgraph.prebuilt import ToolExecutor
from langchain_core.messages import HumanMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import AzureChatOpenAI
import json
from datetime import datetime

class ClaimState(TypedDict):
    """State for the claim processing workflow"""
    claim_reference: str
    url: str
    claim_data_path: str
    portal_data_path: str
    extracted_data_path: str
    extracted_content: str
    validation_result: Dict
    fraud_result: Dict
    consistency_result: Dict
    final_result: Dict
    processing_timestamp: str

def create_claim_processing_graph(llm: AzureChatOpenAI, tools: Dict[str, Any]) -> Graph:
    """Create the claim processing workflow graph"""
    
    # Initialize the graph
    workflow = StateGraph(ClaimState)
    
    # Define the nodes
    def extract_content(state: ClaimState) -> ClaimState:
        """Extract content from the URL"""
        result = tools["extract_contents_tool"](state["url"])
        return {
            "extracted_content": result,
            "processing_timestamp": datetime.utcnow().isoformat()
        }
    
    def validate_claim(state: ClaimState) -> ClaimState:
        """Validate the claim amount"""
        result = tools["validate_claim_amount_tool"](state["claim_data_path"])
        return {
            "validation_result": result,
            "processing_timestamp": datetime.utcnow().isoformat()
        }
    
    def detect_fraud(state: ClaimState) -> ClaimState:
        """Detect potential fraud"""
        result = tools["detect_fraud_tool"](state["claim_data_path"])
        return {
            "fraud_result": result,
            "processing_timestamp": datetime.utcnow().isoformat()
        }
    
    def verify_consistency(state: ClaimState) -> ClaimState:
        """Verify data consistency"""
        result = tools["verify_data_consistency_tool"](
            state["portal_data_path"],
            state["extracted_data_path"]
        )
        return {
            "consistency_result": result,
            "processing_timestamp": datetime.utcnow().isoformat()
        }
    
    def merge_results(state: ClaimState) -> ClaimState:
        """Merge all results into a final response"""
        # Create the final result object
        final_result = {
            "claim_reference": state["claim_reference"],
            "processing_timestamp": datetime.utcnow().isoformat(),
            "processing_steps": {
                "content_extraction": {
                    "timestamp": state["processing_timestamp"],
                    "status": "completed"
                },
                "claim_validation": {
                    "timestamp": state["processing_timestamp"],
                    "status": "completed",
                    "results": {
                        "score": state["validation_result"].score,
                        "is_valid": state["validation_result"].is_valid,
                        "explanation": state["validation_result"].explanation,
                        "procedure_code": state["validation_result"].procedure_code,
                        "standard_cost": state["validation_result"].standard_cost,
                        "deviation_percentage": state["validation_result"].deviation_percentage
                    }
                },
                "fraud_detection": {
                    "timestamp": state["processing_timestamp"],
                    "status": "completed",
                    "results": {
                        "score": state["fraud_result"].score,
                        "risk_level": state["fraud_result"].risk_level,
                        "explanation": state["fraud_result"].explanation,
                        "red_flags": state["fraud_result"].red_flags,
                        "provider_status": state["fraud_result"].provider_status,
                        "similar_claims": state["fraud_result"].similar_claims
                    }
                },
                "data_consistency": {
                    "timestamp": state["processing_timestamp"],
                    "status": "completed",
                    "results": {
                        "score": state["consistency_result"].score,
                        "is_consistent": state["consistency_result"].is_consistent,
                        "explanation": state["consistency_result"].explanation,
                        "mismatches": state["consistency_result"].mismatches,
                        "critical_mismatches": state["consistency_result"].critical_mismatches
                    }
                }
            }
        }
        
        # Generate a summary using the LLM
        prompt = ChatPromptTemplate.from_messages([
            ("system", "You are an expert claims analyst. Summarize the following claim analysis results:"),
            MessagesPlaceholder(variable_name="results"),
            ("human", f"Please provide a concise summary of the claim analysis for claim reference {state['claim_reference']}, highlighting any critical issues or concerns.")
        ])
        
        chain = prompt | llm
        
        summary = chain.invoke({
            "results": json.dumps(final_result, indent=2)
        })
        
        final_result["summary"] = summary.content
        
        # Save the results to a file
        output_file = f"claims/processed/{state['claim_reference']}_results.json"
        with open(output_file, 'w') as f:
            json.dump(final_result, f, indent=2)
        
        return {"final_result": final_result}
    
    # Add nodes to the graph
    workflow.add_node("extract_content", extract_content)
    workflow.add_node("validate_claim", validate_claim)
    workflow.add_node("detect_fraud", detect_fraud)
    workflow.add_node("verify_consistency", verify_consistency)
    workflow.add_node("merge_results", merge_results)
    
    # Define the edges
    workflow.add_edge("extract_content", "validate_claim")
    workflow.add_edge("validate_claim", "detect_fraud")
    workflow.add_edge("detect_fraud", "verify_consistency")
    workflow.add_edge("verify_consistency", "merge_results")
    
    # Set the entry point
    workflow.set_entry_point("extract_content")
    
    # Set the exit point
    workflow.set_finish_point("merge_results")
    
    return workflow.compile() 