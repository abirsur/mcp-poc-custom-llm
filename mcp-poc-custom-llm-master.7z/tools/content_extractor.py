import trafilatura
from trafilatura.settings import use_config
from requests.exceptions import RequestException
from mcp.shared.exceptions import McpError
from mcp.types import ErrorData, INTERNAL_ERROR, INVALID_PARAMS

def extract_contents(url: str) -> str:
    """
    Extract the main content from a webpage using trafilatura library.
    
    Args:
        url: The URL of the webpage to extract content from
        
    Returns:
        str: The extracted content in plain text format
    """
    try:
        if not url.startswith(("http://", "https://")):
            raise ValueError("URL must start with http:// or https://")

        # Configure trafilatura
        config = use_config()
        config.set("DEFAULT", "EXTRACTION_TIMEOUT", "30")
        
        # Download and extract content
        downloaded = trafilatura.fetch_url(url)
        if downloaded is None:
            raise McpError(
                ErrorData(
                    INTERNAL_ERROR,
                    "Failed to download the webpage content"
                )
            )
            
        # Extract main content
        content = trafilatura.extract(downloaded, config=config)
        if content is None:
            raise McpError(
                ErrorData(
                    INTERNAL_ERROR,
                    "Failed to extract content from the webpage"
                )
            )

        return content

    except ValueError as e:
        raise McpError(ErrorData(INVALID_PARAMS, str(e))) from e
    except RequestException as e:
        raise McpError(ErrorData(INTERNAL_ERROR, f"Request error: {str(e)}")) from e
    except Exception as e:
        raise McpError(ErrorData(INTERNAL_ERROR, f"Unexpected error: {str(e)}")) from e 