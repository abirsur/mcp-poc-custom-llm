import json
from mcp.shared.exceptions import McpError
from mcp.types import ErrorData, INTERNAL_ERROR, INVALID_PARAMS
from models.validation_models import ValidationResult
from models import ExtractedDataModel

def validate_claim_amount(claim_data_path: str, llm) -> ValidationResult:
    """
    Validate the claimed amount against standard procedure costs.
    
    Args:
        claim_data_path: Path to the JSON file containing claim data
        llm: Language model instance for inference
        
    Returns:
        ValidationResult: Validation results including score and explanation
    """
    try:
        # Load claim data
        with open(claim_data_path, 'r') as f:
            claim_data = json.load(f)
        
        # Load standard procedure costs
        with open('procedure_costs.json', 'r') as f:
            standard_costs = json.load(f)
        
        # Create model instance from claim data
        claim = ExtractedDataModel(**claim_data)
        
        # Get the first procedure code (assuming it's the main procedure)
        if not claim.procedures:
            raise McpError(
                ErrorData(
                    INVALID_PARAMS,
                    "No procedures found in claim data"
                )
            )
        
        procedure_code = claim.procedures[0]["code"]
        
        # Check if procedure code exists in standard costs
        if procedure_code not in standard_costs:
            # Use OpenAI to infer the procedure code
            prompt = f"""Given the procedure '{claim.procedures[0]["name"]}', what is the most likely medical CPT code?
            Return only the CPT code number."""
            
            response = llm.invoke(prompt)
            inferred_code = response.strip()
            
            if inferred_code not in standard_costs:
                return ValidationResult(
                    score=0,
                    is_valid=False,
                    explanation=f"Could not find standard cost data for procedure {claim.procedures[0]['name']}",
                    procedure_code=procedure_code,
                    standard_cost=0.0,
                    deviation_percentage=0.0
                )
            
            procedure_code = inferred_code
        
        # Get standard cost data
        standard_cost_data = standard_costs[procedure_code]
        standard_cost = standard_cost_data["average_cost"]
        
        # Calculate deviation percentage
        deviation = ((claim.claimed_amount - standard_cost) / standard_cost) * 100
        
        # Calculate score based on deviation
        if abs(deviation) <= 10:
            score = 95
            is_valid = True
        elif abs(deviation) <= 25:
            score = 80
            is_valid = True
        elif abs(deviation) <= 50:
            score = 60
            is_valid = False
        else:
            score = 30
            is_valid = False
        
        # Generate explanation
        if is_valid:
            explanation = f"The claimed amount of ${claim.claimed_amount:,.2f} for procedure {procedure_code} ({claim.procedures[0]['name']}) "
            explanation += f"deviates from the standard average cost (${standard_cost:,.2f}) by {abs(deviation):.1f}%, "
            explanation += "which is within the acceptable range."
        else:
            explanation = f"The claimed amount of ${claim.claimed_amount:,.2f} for procedure {procedure_code} ({claim.procedures[0]['name']}) "
            explanation += f"deviates significantly from the standard average cost (${standard_cost:,.2f}) by {abs(deviation):.1f}%, "
            explanation += "which is outside the acceptable range."
        
        return ValidationResult(
            score=score,
            is_valid=is_valid,
            explanation=explanation,
            procedure_code=procedure_code,
            standard_cost=standard_cost,
            deviation_percentage=deviation
        )
        
    except FileNotFoundError as e:
        raise McpError(ErrorData(INVALID_PARAMS, f"File not found: {str(e)}")) from e
    except json.JSONDecodeError as e:
        raise McpError(ErrorData(INVALID_PARAMS, f"Invalid JSON data: {str(e)}")) from e
    except Exception as e:
        raise McpError(ErrorData(INTERNAL_ERROR, f"Error validating claim: {str(e)}")) from e 